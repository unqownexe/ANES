# ANES AI Backend

Yerel GGUF (llama.cpp) tabanlı, OpenAI uyumlu yapay zekâ sunucusu.

---

## Hızlı Başlangıç

### İlk kurulum (başka bir cihazda)

```bat
FirstInstall.cmd
```

Her şeyi hazırlar — tüm adımlar **anlık ilerleme** gösterir:

1. Proje dosyalarını GitHub'dan (`unqownexe/ANES`) indirir (klasör boşsa).
2. Python'u (gerekirse) indirir ve kurar.
3. `.venv` sanal ortamını oluşturur, bağımlılıkları kurar.
4. Varsayılan modeli (isteğe bağlı) indirir.

### Çalıştırma

```bat
start.bat
```

Sunucu: `http://127.0.0.1:8493` · Docs: `http://127.0.0.1:8493/docs`

> `start.bat` çalıştırıldığında backend açılırken **otomatik güncelleme servisi
> de başlar**: açılıştan ~15 sn sonra ve ardından **her 30 dakikada bir**
> GitHub'daki yeni sürümü kontrol eder.

---

## Klasör Yapısı

```
ANES_AI_Backend/
├── app/                     # Uygulama kodu (FastAPI)
│   ├── main.py              # Uç noktalar (+ /v1/update/*)
│   ├── updater.py           # Güncelleme çekirdeği + 30 dk servisi
│   ├── config.py            # Yapılandırma
│   ├── engine.py            # llama.cpp motoru
│   └── ...
│
├── config/                  # ⚙️ Yapılandırma dosyaları (JSON)
│   ├── Models.json          # Model kataloğu
│   └── Updater.json         # Güncelleme ayarları
│
├── Changes/                 # 📦 Sürüm bildirimi + changelog
│   ├── Version.json
│   └── ChangeLog.md
│
├── Models/                  # 📥 İndirilen GGUF modelleri (git dışı)
│
├── test/                    # 💬 Node.js terminal sohbet istemcisi
│
├── updater/                 # 🔄 Güncelleme CLI'si (Python)
│   ├── update.py
│   └── README.md
│
├── tools/                   # 🛠️ Araçlar (kursam + yayınlama)
│   ├── install.bat          # Bağımlılık kurulumu (install.log üretir)
│   ├── first-install.ps1    # İlk kurulum motoru
│   ├── publish-update.ps1   # Sürüm yayınlama motoru
│   └── PublishUpdate.bat    # Yayınlama arayüzü
│
├── FirstInstall.cmd         # 🚀 İlk kurulum (tek tik)
├── start.bat                # ▶️ Sunucuyu başlat
├── update.bat               # 🔄 Güncelleme yöneticisi (menü)
├── run.py                   # Giriş noktası
└── requirements.txt
```

---

## Kök Dosyalar (yalnızca giriş noktaları)

| Dosya | Açıklama |
|-------|----------|
| `FirstInstall.cmd` | İlk kurulum (GitHub'dan indirir + kurar) |
| `start.bat` | Sunucuyu başlatır (güncelleme servisi dahil) |
| `update.bat` | Güncelleme yöneticisi (1-2-3-4 menü) |
| `run.py` | Python giriş noktası (`start.bat` çağırır) |
| `requirements.txt` | Python bağımlılıkları |
| `README.md` | Bu dosya |

---

## Otomatik Güncelleme

```bat
update.bat
```

Menü (rakamla): `1` kontrol · `2` indir/uygula · `3` ayarlar · `4` changelog · `5` durum · `0` çıkış

- **Beta** sürümler isteğe bağlıdır (ayarlardan açılır).
- **Zorunlu** (`mandatory`) sürümler atlanmaz, uygulanır.
- Arka planda **30 dakikada bir** otomatik kontrol yapılır.

Ayrıntı: [`updater/README.md`](updater/README.md)

---

## Sürüm Yayınlama (geliştirici)

```bat
tools\PublishUpdate.bat
```

Sürüm numarasını, değişiklikleri, zorunlu/beta durumunu sorar; dağıtım `.zip`
arşivini üretir (sha256 ile), [`Changes/Version.json`](Changes/Version.json) ve
[`Changes/ChangeLog.md`](Changes/ChangeLog.md) dosyalarını günceller ve arşivi
GitHub deposunun `Main/Updates/Downloads/` klasörüne kopyalar.

---

## API Uç Noktaları

| Yöntem | Yol | Açıklama |
|--------|-----|----------|
| POST | `/v1/chat/completions` | Sohbet (stream & non-stream, tool calling, web) |
| GET | `/v1/models` | Model kataloğu |
| POST | `/v1/models/download` | Model indir |
| POST | `/v1/models/load` | Model yükle |
| GET | `/v1/status` | Cihaz + süreç + metrikler |
| GET | `/v1/update/check` | Güncelleme denetle |
| POST | `/v1/update/apply` | Güncellemeyi uygula |
| GET | `/health` | Sağlık |

Tam liste ve örnekler için `http://127.0.0.1:8493/docs`.
