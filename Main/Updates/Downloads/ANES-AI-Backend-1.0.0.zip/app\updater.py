# -*- coding: utf-8 -*-
"""ANES AI — GitHub tabanlı otomatik güncelleme çekirdeği.

Bu modül üç katmandan oluşur:

1. **Manifest** (`Version.json`)
   GitHub deposundaki ``Main/Updates/Version.json`` (ve yedek yollar) okunur.
   Bu dosya, sürümlerin listesini, kanalını (stable/beta), zorunlu olup
   olmadığını ve dosya listelerini içerir.

2. **Updater** (`updater.py` sınıfı)
   Yerel sürüm (``Updater.json``) ile uzak manifesti karşılaştırır, hangi
   sürümün indirileceğine karar verir, dosyaları GitHub raw / arşiv üzerinden
   indirir, doğrular (sha256), yedek alır ve uygular.

3. **UpdateService** (`update_service` örneği)
   Arka planda 30 dakikada bir kontrol eden iş parçacığını (thread) yönetir.
   FastAPI bu servisi kullanarak HTTP uç noktaları sunar.

Tüm ağ işlemleri yalnızca ``urllib``/``urllib3`` ile yapılır; ek bağımlılık
gerekmez (``requests`` varsa o da otomatik kullanılır).

Not: İndirme adresi boş bırakılan sürümlerde (örnek manifest) sistem, kod
dosyalarını indirmek yerine "post-update" komutlarını çalıştırır ve sürüm
numarasını günceller. Gerçek dağıtımda ``archive`` alanına bir ``.zip`` bağlantısı
eklendiğinde dosyalar otomatik olarak senkronize edilir.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from urllib import request as _urlreq
from urllib import error as _urlerr

# Proje kökü ve varsayılan yollar
BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = BASE_DIR / "config" / "Updater.json"
DEFAULT_MANIFEST = BASE_DIR / "Changes" / "Version.json"
BACKUP_DIR = BASE_DIR / ".backups"
STATE_DIR = BASE_DIR / ".updater"
LOG_FILE = STATE_DIR / "updater.log"

USER_AGENT = "ANES-Updater/1.0 (+https://github.com/unqownexe/ANES)"
TIMEOUT = 20

# Güncelleme tarafından ÜZERİNE YAZILMAYACAK yollar (kullanıcı verisi)
PROTECTED_PREFIXES = (
    "Models/",
    "Models\\",
    ".venv/",
    ".venv\\",
    ".backups/",
    ".backups\\",
    ".updater/",
    ".updater\\",
    ".git/",
    ".git\\",
)


# ---------------------------------------------------------------------------
# Sürüm karşılaştırma
# ---------------------------------------------------------------------------
def _version_key(value):
    """'1.2.10-beta' -> (1,2,10,'beta'). Karşılaştırma için güvenli anahtar."""
    value = str(value or "0").strip()
    m = re.match(r"^v?(\d+(?:\.\d+)*)\s*(?:[-_+ ]?(.*))?$", value)
    if not m:
        return (0,)
    nums = tuple(int(x) for x in m.group(1).split("."))
    tail = (m.group(2) or "").strip().lower()
    # Boş tail (kararlı sürüm) beta/pre'den daha üstündür.
    return nums + ((0, "") if not tail else (1, tail))


def parse_version(value):
    """Sürümü (major, minor, patch, pre) bileşenlerine ayırır."""
    key = _version_key(value)
    nums = key[:-1] if isinstance(key[-1], tuple) else key
    nums = tuple(n for n in nums if isinstance(n, int))
    return nums + (0, 0, 0)[: max(0, 3 - len(nums))]


def compare_versions(a, b):
    """a > b ise 1, a < b ise -1, eşitse 0 döndürür."""
    ka, kb = _version_key(a), _version_key(b)
    if ka > kb:
        return 1
    if ka < kb:
        return -1
    return 0


# ---------------------------------------------------------------------------
# Konsol kodlaması (Windows cp1254 "→", "─" gibi karakterleri yazamaz)
# ---------------------------------------------------------------------------
def _reconfigure_stdout() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass


_reconfigure_stdout()


# ---------------------------------------------------------------------------
# Loglama
# ---------------------------------------------------------------------------
def log(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        with LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass
    try:
        print(line)
    except Exception:  # noqa: BLE001
        pass


# ---------------------------------------------------------------------------
# HTTP yardımcıları
# ---------------------------------------------------------------------------
def http_get(url: str, timeout: int = TIMEOUT) -> bytes:
    """Basit, bağımlılıksız HTTP GET. İçeriği bayt olarak döndürür."""
    req = _urlreq.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "application/json, text/plain, */*",
        "Cache-Control": "no-cache",
    })
    with _urlreq.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def http_get_json(url: str, timeout: int = TIMEOUT) -> dict:
    raw = http_get(url, timeout)
    # GitHub bazen BOM döndürebilir; güvenli çöz.
    text = raw.decode("utf-8-sig", errors="replace")
    return json.loads(text)


def download_to(url: str, dest: Path, on_progress=None) -> Path:
    """url -> dest indirir. (indirilen, toplam) ile ilerleme bildirir."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = _urlreq.Request(url, headers={"User-Agent": USER_AGENT})
    with _urlreq.urlopen(req, timeout=TIMEOUT) as resp:
        total = int(resp.headers.get("Content-Length", 0) or 0)
        got = 0
        with tmp.open("wb") as fh:
            while True:
                chunk = resp.read(1024 * 256)
                if not chunk:
                    break
                fh.write(chunk)
                got += len(chunk)
                if on_progress:
                    on_progress(got, total)
    if dest.exists():
        dest.unlink()
    tmp.rename(dest)
    return dest


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------------------
# Yapılandırma
# ---------------------------------------------------------------------------
DEFAULT_CONFIG_DATA = {
    "schema": 1,
    "installedVersion": "1.0.0",
    "repo": {
        "owner": "unqownexe",
        "name": "ANES",
        "branch": "main",
        "manifestPaths": ["Main/Updates", "Updates", "Changes"],
    },
    "channels": {"current": "stable", "allowBeta": False},
    "autoUpdate": {
        "enabled": True,
        "checkIntervalMinutes": 30,
        "applyAutomatically": False,
        "requireConfirmationForMandatory": False,
    },
    "update": {
        "strategy": "auto",
        "backup": True,
        "restartAfterUpdate": False,
        "restartCommand": "start.bat",
    },
    "postUpdate": {"commands": [], "pip": [], "message": ""},
    "ignoredVersions": [],
    "lastCheck": 0,
    "lastApplied": "",
    "lastResult": None,
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


@dataclass
class UpdateResult:
    ok: bool = False
    status: str = "idle"            # ok | update_available | uptodate | error
    message: str = ""
    current: str = ""
    latest: str = ""
    target: str = ""
    mandatory: bool = False
    beta: bool = False
    applied: bool = False
    backup: str = ""
    log: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


class Updater:
    """Yerel kurulumu GitHub'daki sürümlerle senkronize eden çekirdek."""

    def __init__(self, config_path: Path = DEFAULT_CONFIG,
                 manifest_path: Path = DEFAULT_MANIFEST):
        self.config_path = Path(config_path)
        self.local_manifest_path = Path(manifest_path)
        self.config = self.load_config()
        self.remote_manifest = None
        self._manifest_source = None

    # ---------------- yapılandırma ----------------
    def load_config(self) -> dict:
        data = dict(DEFAULT_CONFIG_DATA)
        if self.config_path.exists():
            try:
                data = _deep_merge(DEFAULT_CONFIG_DATA,
                                   json.loads(self.config_path.read_text("utf-8-sig")))
            except Exception as e:  # noqa: BLE001
                log(f"[config] okunamadı: {e}")
        return data

    def save_config(self) -> None:
        self.config_path.write_text(
            json.dumps(self.config, indent=4, ensure_ascii=False), encoding="utf-8"
        )

    @property
    def current_version(self) -> str:
        return str(self.config.get("installedVersion", "0.0.0"))

    @property
    def channel(self) -> str:
        return str(self.config.get("channels", {}).get("current", "stable"))

    @property
    def allow_beta(self) -> bool:
        return bool(self.config.get("channels", {}).get("allowBeta", False))

    # ---------------- manifest okuma ----------------
    def manifest_urls(self) -> list[str]:
        repo = self.config.get("repo", {})
        owner = repo.get("owner", "unqownexe")
        name = repo.get("name", "ANES")
        branch = repo.get("branch", "main")
        paths = repo.get("manifestPaths", ["Main/Updates", "Updates", "Changes"])
        urls = []
        for p in paths:
            p = p.strip("/").replace("\\", "/")
            urls.append(
                f"https://raw.githubusercontent.com/{owner}/{name}/{branch}/{p}/Version.json"
            )
            # Yedek: GitHub API (raw erişilemezse)
            urls.append(
                f"https://api.github.com/repos/{owner}/{name}/contents/"
                f"{p}/Version.json?ref={branch}"
            )
        # Yerel bildirim her zaman en son deneme (çevrimdışı test)
        urls.append("file://" + str(self.local_manifest_path))
        return urls

    def fetch_manifest(self) -> dict:
        """Uzak (veya yerel) bildirimi indirir. Bulunan ilk geçerli JSON kazanır."""
        errors = []
        for url in self.manifest_urls():
            try:
                if url.startswith("file://"):
                    local = Path(url[7:])
                    if not local.exists():
                        continue
                    data = json.loads(local.read_text("utf-8-sig"))
                else:
                    data = http_get_json(url)
                    # GitHub API içerik şekli: {"content": base64,...}
                    if isinstance(data, dict) and "content" in data and "encoding" in data:
                        import base64
                        data = json.loads(
                            base64.b64decode(data["content"]).decode("utf-8-sig")
                        )
                if isinstance(data, dict) and (
                    "releases" in data or "versions" in data or "latest" in data
                ):
                    self.remote_manifest = self._normalize_manifest(data)
                    self._manifest_source = url
                    return self.remote_manifest
                errors.append(f"{url}: geçersiz bildirim")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{url}: {e}")
        raise RuntimeError("Bildirim alınamadı. " + " | ".join(errors[:4]))

    @staticmethod
    def _normalize_manifest(data: dict) -> dict:
        """Eski/yeni şemaları ortak biçime çevirir."""
        releases = data.get("releases") or data.get("VersionDetails") or {}
        norm = {}
        for ver, info in releases.items():
            info = dict(info or {})
            norm[ver] = {
                "version": info.get("version", ver),
                "channel": info.get("channel",
                                    "beta" if info.get("beta") else "stable"),
                "releaseType": info.get("releaseType", ""),
                "beta": bool(info.get("beta", False)),
                "mandatory": bool(info.get("mandatory", False)),
                "minFrom": info.get("minFrom", "0.0.0"),
                "title": info.get("title", ""),
                "description": info.get("description", ""),
                "releasedAt": info.get("releasedAt", ""),
                "timestamp": info.get("timestamp", info.get("updatedAt", 0)),
                "changes": info.get("changes", []),
                "archive": info.get("archive", info.get("downloadLink", "")),
                "sha256": info.get("sha256", ""),
                "files": info.get("files", []),
                "postUpdate": info.get("postUpdate", {}),
            }
        latest = data.get("latest", "")
        if not latest and norm:
            latest = max(norm.keys(), key=_version_key)
        return {
            "schema": data.get("schema", 1),
            "channel": data.get("channel", "stable"),
            "latest": latest,
            "minimumSupported": data.get("minimumSupported", "0.0.0"),
            "releasedAt": data.get("releasedAt", ""),
            "generatedAt": data.get("generatedAt", data.get("lastUpdTimestamp", 0)),
            "changelog": data.get("changelog", "ChangeLog.md"),
            "repository": data.get("repository", {}),
            "releases": norm,
        }

    # ---------------- sürüm seçimi ----------------
    def _candidates(self) -> list[str]:
        """Kanal/beta filtrelerini uygulayıp artan sırada sürüm döndürür."""
        manifest = self.remote_manifest or self.fetch_manifest()
        out = []
        for ver, info in manifest["releases"].items():
            if info.get("beta") and not self.allow_beta:
                continue
            if compare_versions(ver, self.current_version) > 0:
                out.append(ver)
        return sorted(out, key=_version_key)

    def resolve_target(self, requested: str | None = None) -> str | None:
        """İndirilecek hedef sürümü belirler.

        - ``requested`` verilirse ve yeniyse onu kullanır.
        - Zorunlu (mandatory) bir güncelleme varsa zinciri baştan başlatır.
        - Aksi hâlde bulunabilecek EN SON adım adım sürümü hedefler.
        """
        manifest = self.remote_manifest or self.fetch_manifest()
        if requested:
            if requested in manifest["releases"]:
                return requested
            raise ValueError(f"Bilinmeyen sürüm: {requested}")

        chain = self._candidates()
        if not chain:
            return None
        # Zorunlu bir sürüm varsa zincirin en eskisini hedefle (adım adım).
        for ver in chain:
            if manifest["releases"][ver].get("mandatory"):
                return chain[0]
        return chain[-1]

    def check(self, apply_after: bool = False) -> UpdateResult:
        """Uzak bildirimi alır ve güncelleme gerekip gerekmediğini döndürür."""
        res = UpdateResult(current=self.current_version)
        try:
            self.remote_manifest = self.fetch_manifest()
        except Exception as e:  # noqa: BLE001
            res.ok, res.status, res.message = False, "error", str(e)
            log(f"[check] hata: {e}")
            self._record_result(res)
            return res

        manifest = self.remote_manifest
        res.latest = manifest["latest"]
        self.config["lastCheck"] = int(time.time() * 1000)

        target = self.resolve_target()
        if not target:
            res.ok, res.status = True, "uptodate"
            res.message = f"En güncel sürümdesiniz ({self.current_version})."
            res.target = self.current_version
            self._record_result(res)
            return res

        info = manifest["releases"][target]
        res.ok, res.status = True, "update_available"
        res.target = target
        res.mandatory = bool(info.get("mandatory"))
        res.beta = bool(info.get("beta"))
        res.message = (
            f"Yeni {'zorunlu ' if res.mandatory else ''}güncelleme: "
            f"{self.current_version} → {target} ({info.get('title') or info.get('releaseType')})"
        )
        log(f"[check] {res.message}")
        self._record_result(res)

        if apply_after:
            return self.apply(target)
        return res

    def _record_result(self, res: UpdateResult) -> None:
        self.config["lastResult"] = {
            "time": int(time.time() * 1000),
            "status": res.status,
            "message": res.message,
            "current": res.current,
            "target": res.target,
        }
        try:
            self.save_config()
        except Exception:
            pass

    # ---------------- dosya senkronizasyonu ----------------
    def _raw_url(self, rel_path: str, version: str | None = None) -> str:
        repo = self.config.get("repo", {})
        owner = repo.get("owner", "unqownexe")
        name = repo.get("name", "ANES")
        branch = repo.get("branch", "main")
        ver = version or self.current_version
        rel = rel_path.replace("\\", "/")
        # Hem yeni (Main/Updates/<ver>/...) hem eski (repo kökü) yerleşimi dene.
        return f"https://raw.githubusercontent.com/{owner}/{name}/{branch}/{rel}"

    def _safe_rel(self, rel: str) -> str:
        rel = rel.replace("\\", "/").lstrip("/")
        if ".." in rel.split("/"):
            raise ValueError(f"Güvenli olmayan yol: {rel}")
        for pref in PROTECTED_PREFIXES:
            if rel.startswith(pref.replace("\\", "/")):
                raise ValueError(f"Korunan yol: {rel}")
        return rel

    def _apply_archive(self, version: str, info: dict, res: UpdateResult) -> bool:
        """Sürümün ``archive`` (.zip) bağlantısını indirip kök dizine açar."""
        url = info.get("archive")
        if not url:
            return False
        log(f"[apply] arşiv indiriliyor: {url}")
        tmp_zip = STATE_DIR / f"update-{version}.zip"
        download_to(url, tmp_zip,
                    on_progress=lambda g, t: log(f"[apply] {g}/{t or '?'} bayt"))
        if info.get("sha256"):
            got = sha256_file(tmp_zip)
            if got.lower() != str(info["sha256"]).lower():
                raise RuntimeError("Arşiv sha256 uyuşmuyor — indirme bozuk.")
        with zipfile.ZipFile(tmp_zip) as z:
            for member in z.namelist():
                rel = self._safe_rel(member)
                if member.endswith("/"):
                    continue
                dest = BASE_DIR / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                with z.open(member) as src, dest.open("wb") as out:
                    shutil.copyfileobj(src, out)
        tmp_zip.unlink(missing_ok=True)
        return True

    def _apply_file_list(self, version: str, info: dict, res: UpdateResult) -> bool:
        """Sürümün ``files`` listesindeki tek tek dosyaları indirir."""
        files = info.get("files") or []
        if not files:
            return False
        for entry in files:
            rel = self._safe_rel(entry.get("path", ""))
            url = entry.get("url") or self._raw_url(rel, version)
            dest = BASE_DIR / rel
            download_to(url, dest)
            if entry.get("sha256"):
                if sha256_file(dest).lower() != str(entry["sha256"]).lower():
                    raise RuntimeError(f"sha256 uyuşmuyor: {rel}")
            log(f"[apply] dosya güncellendi: {rel}")
        return True

    def _run_post_update(self, info: dict, res: UpdateResult) -> None:
        """Sürümün postUpdate komutlarını (terminal/pip) çalıştırır."""
        post = _deep_merge(
            self.config.get("postUpdate", {}), info.get("postUpdate", {})
        )
        for cmd in post.get("commands", []) or []:
            log(f"[post] komut: {cmd}")
            try:
                proc = subprocess.run(cmd, shell=True, cwd=str(BASE_DIR),
                                      capture_output=True, text=True)
                out = (proc.stdout or "").strip()
                err = (proc.stderr or "").strip()
                if out:
                    log(f"[post] > {out}")
                if err:
                    log(f"[post] ! {err}")
                res.log.append({"command": cmd, "returncode": proc.returncode})
            except Exception as e:  # noqa: BLE001
                log(f"[post] komut hatası ({cmd}): {e}")
                res.log.append({"command": cmd, "error": str(e)})
        for pkg in post.get("pip", []) or []:
            venv_py = BASE_DIR / ".venv" / "Scripts" / "python.exe"
            py = str(venv_py) if venv_py.exists() else sys.executable
            cmd = f'"{py}" -m pip install {pkg}'
            log(f"[post] pip: {cmd}")
            try:
                subprocess.run(cmd, shell=True, cwd=str(BASE_DIR))
                res.log.append({"pip": pkg, "ok": True})
            except Exception as e:  # noqa: BLE001
                res.log.append({"pip": pkg, "error": str(e)})
        if post.get("message"):
            log(f"[post] {post['message']}")

    def _backup(self, version: str) -> str:
        """Güncelleme öncesi önemli dosyaların yedeğini alır."""
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        dest = BACKUP_DIR / f"{version}-{stamp}"
        dest.mkdir(parents=True, exist_ok=True)
        keep = ["config/Updater.json", "config/Models.json",
                "Changes/Version.json", "Changes/ChangeLog.md", "requirements.txt"]
        for rel in keep:
            src = BASE_DIR / rel
            if src.exists():
                tgt = dest / rel
                tgt.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, tgt)
        return str(dest)

    def _write_remote_manifest_cache(self) -> None:
        """Uzak bildirimi yerel Changes/Version.json'a yazar (tek doğruluk kaynağı)."""
        if not self.remote_manifest:
            return
        serializable = {
            "schema": self.remote_manifest.get("schema", 2),
            "channel": self.remote_manifest.get("channel", "stable"),
            "latest": self.remote_manifest.get("latest", ""),
            "minimumSupported": self.remote_manifest.get("minimumSupported", "0.0.0"),
            "releasedAt": self.remote_manifest.get("releasedAt", ""),
            "generatedAt": self.remote_manifest.get("generatedAt", 0),
            "changelog": self.remote_manifest.get("changelog", "ChangeLog.md"),
            "repository": self.remote_manifest.get("repository", {}),
            "releases": self.remote_manifest.get("releases", {}),
        }
        tmp = self.local_manifest_path.with_suffix(".json.tmp")
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(serializable, indent=4, ensure_ascii=False),
                       encoding="utf-8")
        tmp.replace(self.local_manifest_path)

    # ---------------- uygulama ----------------
    def apply(self, target: str | None = None, force: bool = False) -> UpdateResult:
        """Belirlenen sürümü indirir, doğrular ve uygular."""
        old_version = self.current_version
        res = UpdateResult(current=old_version)
        manifest = self.remote_manifest or self.fetch_manifest()
        target = target or self.resolve_target()
        if not target:
            res.ok, res.status, res.message = True, "uptodate", "Güncelleme gerekmiyor."
            return res
        if compare_versions(target, self.current_version) <= 0 and not force:
            res.ok, res.status = True, "uptodate"
            res.message = f"{target} zaten yüklü."
            return res

        info = manifest["releases"].get(target)
        if not info:
            res.ok, res.status, res.message = False, "error", f"Sürüm bulunamadı: {target}"
            return res

        res.target, res.mandatory, res.beta = target, info.get("mandatory", False), info.get("beta", False)
        log(f"[apply] {self.current_version} → {target} uygulanıyor...")

        try:
            if self.config.get("update", {}).get("backup", True):
                res.backup = self._backup(target)
                log(f"[apply] yedek: {res.backup}")

            strategy = self.config.get("update", {}).get("strategy", "auto")
            did = False
            if strategy in ("auto", "archive"):
                did = self._apply_archive(target, info, res)
            if not did and strategy in ("auto", "files"):
                did = self._apply_file_list(target, info, res)
            if did:
                log("[apply] dosyalar senkronize edildi.")

            # Post-update komutları
            self._run_post_update(info, res)

            # Sürüm numarasını güncelle + uzak bildirimi önbelleğe yaz
            self.config["installedVersion"] = target
            self.config["lastApplied"] = target
            self._write_remote_manifest_cache()
            # ChangeLog varsa indirmeyi dene (opsiyonel)
            self._try_update_changelog(info)

            res.ok, res.applied, res.status = True, True, "ok"
            res.message = (
                f"Güncelleme uygulandı: {old_version} → {target}"
                + ("  (ZORUNLU)" if res.mandatory else "")
                + ("  [beta]" if res.beta else "")
            )
            log(f"[apply] {res.message}")
            self._record_result(res)

            if self.config.get("update", {}).get("restartAfterUpdate"):
                self._restart()
            return res
        except Exception as e:  # noqa: BLE001
            res.ok, res.status, res.message = False, "error", str(e)
            log(f"[apply] hata: {e}")
            self._record_result(res)
            return res

    def _try_update_changelog(self, info: dict) -> None:
        changelog = info.get("changelog") or self.remote_manifest.get("changelog")
        if not changelog:
            return
        repo = self.config.get("repo", {})
        owner, name = repo.get("owner"), repo.get("name")
        branch = repo.get("branch", "main")
        for base in (f"{owner}/{name}/{branch}/Main/Updates",
                     f"{owner}/{name}/{branch}"):
            url = f"https://raw.githubusercontent.com/{base}/{changelog}"
            try:
                data = http_get(url)
                self.local_manifest_path.parent.mkdir(parents=True, exist_ok=True)
                (self.local_manifest_path.parent / "ChangeLog.md").write_bytes(data)
                log("[apply] ChangeLog.md güncellendi.")
                return
            except Exception:
                continue

    def _restart(self) -> None:
        """Yapılandırılmış komutla backendi yeniden başlatır."""
        cmd = self.config.get("update", {}).get("restartCommand", "")
        if not cmd:
            return
        log(f"[apply] yeniden başlatma: {cmd}")

        def _spawn():
            time.sleep(1.5)
            try:
                flags = 0
                if platform.system() == "Windows":
                    flags = 0x00000008 | 0x00000200  # DETACHED | NEW_PROCESS_GROUP
                    subprocess.Popen(cmd, shell=True, cwd=str(BASE_DIR),
                                     creationflags=flags, close_fds=True)
                else:
                    subprocess.Popen(cmd, shell=True, cwd=str(BASE_DIR),
                                     start_new_session=True)
            except Exception as e:  # noqa: BLE001
                log(f"[apply] yeniden başlatma hatası: {e}")
            os._exit(0)

        threading.Thread(target=_spawn, daemon=True).start()


# ---------------------------------------------------------------------------
# Arka plan servisi (30 dakikada bir kontrol)
# ---------------------------------------------------------------------------
class UpdateService:
    def __init__(self, updater: Updater):
        self.updater = updater
        self._stop = threading.Event()
        self._thread = None
        self._last_state = None

    def start(self) -> bool:
        if self._thread and self._thread.is_alive():
            return False
        if not self.updater.config.get("autoUpdate", {}).get("enabled", True):
            log("[service] otomatik güncelleme kapalı.")
            return False
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="anes-updater")
        self._thread.start()
        log("[service] arka plan güncelleme servisi başladı.")
        return True

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        # İlk kontrol kısa gecikmeyle
        if self._wait(15):
            return
        while not self._stop.is_set():
            try:
                res = self.updater.check()
                self._last_state = res
                auto = self.updater.config.get("autoUpdate", {})
                # Otomatik uygula açıksa; ancak zorunlu sürümlerde onay
                # isteniyorsa kullanıcıya bırak (bekle).
                should_apply = (
                    res.status == "update_available"
                    and auto.get("applyAutomatically")
                    and not (res.mandatory
                             and auto.get("requireConfirmationForMandatory"))
                )
                if should_apply:
                    self.updater.apply(res.target)
            except Exception as e:  # noqa: BLE001
                log(f"[service] kontrol hatası: {e}")
            minutes = int(self.updater.config.get("autoUpdate", {})
                          .get("checkIntervalMinutes", 30))
            if self._wait(max(60, minutes * 60)):
                return

    def _wait(self, seconds: int) -> bool:
        """Bekler; durdurulursa True döndürür."""
        return self._stop.wait(seconds)

    def state(self) -> dict:
        return {
            "running": bool(self._thread and self._thread.is_alive()),
            "intervalMinutes": int(self.updater.config.get("autoUpdate", {})
                                   .get("checkIntervalMinutes", 30)),
            "enabled": bool(self.updater.config.get("autoUpdate", {})
                            .get("enabled", True)),
            "lastCheck": self.updater.config.get("lastCheck", 0),
            "lastResult": self.updater.config.get("lastResult"),
            "current": self.updater.current_version,
            "channel": self.updater.channel,
        }


updater = Updater()
update_service = UpdateService(updater)


def quick_version_info() -> dict:
    """Domain bazlı sürüm bilgisi (yerel bildirimden; ağ kullanmaz)."""
    try:
        data = json.loads(DEFAULT_MANIFEST.read_text("utf-8-sig"))
        norm = Updater._normalize_manifest(data)
        return {
            "installed": updater.current_version,
            "channel": updater.channel,
            "manifestLatest": norm.get("latest", ""),
            "releases": norm.get("releases", {}),
        }
    except Exception as e:  # noqa: BLE001
        return {"installed": updater.current_version, "error": str(e)}
