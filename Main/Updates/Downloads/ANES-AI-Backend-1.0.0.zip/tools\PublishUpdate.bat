@echo off
REM ============================================================
REM  ANES AI - Surum Yayinlama Araci (tools\PublishUpdate.bat)
REM  - Surum/changelog/mandatory/beta sorar
REM  - Dagitim .zip arsivini uretir ve sha256 hesaplar
REM  - Changes\Version.json + Changes\ChangeLog.md gunceller
REM  - Arsivi GitHub deposunun Main\Updates\Downloads klasorune kopyalar
REM ============================================================
setlocal enableextensions
cd /d "%~dp0.."
title ANES AI - Surum Yayinlama
chcp 65001 >nul

echo ==^> Yayinlama araci baslatiliyor...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0publish-update.ps1"
if errorlevel 1 goto fail

echo.
echo Islem tamam. Simdi olusan dosyalari GitHub'a push etmeyi unutmayin.
pause
exit /b 0

:fail
echo.
echo HATA: Surum yayinlanamadi. Girdileri ve yollari kontrol edin.
pause
exit /b 1
