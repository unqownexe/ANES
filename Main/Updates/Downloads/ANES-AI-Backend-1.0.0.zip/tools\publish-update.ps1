# ANES AI — Surum Yayinlama Araci
# ============================================================
# "PublishUpdate.bat" tarafindan cagrilir (ya da dogrudan):
#   powershell -ExecutionPolicy Bypass -File tools\publish-update.ps1
#
# Sorar : yeni surum, degisiklikler, zorunlu mu, beta mi, aciklama.
# Yapar :
#   1) Dagıtim .zip arsivini uretir (Models, .venv, .git, test HARIC)
#   2) Sha256 hesaplar
#   3) Changes\Version.json  -> yeni surum kaydini ekler (eskiler korunur)
#   4) Changes\ChangeLog.md  -> yeni bolumu en uste ekler
#   5) Zip'i GitHub deposunun Main\Updates\Downloads klasorune kopyalar
#
# Parametrelerle sessiz (non-interactive) de calistirilabilir:
#   .\publish-update.ps1 -Version 1.2.0 -Mandatory -Notes @("x","y") -NoAsk
#
param(
    [string]$Root = "",
    [string]$UpdatesDir = "",
    [string]$Version = "",
    [switch]$Mandatory,
    [switch]$Beta,
    [string[]]$Notes = @(),
    [string]$Description = "",
    [switch]$NoAsk,
    [switch]$SkipArchive
)

$ErrorActionPreference = "Stop"
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::InputEncoding  = [System.Text.Encoding]::UTF8
} catch {}

# ---------------------------------------------------------------------------
# Yollar
# ---------------------------------------------------------------------------
$root = $Root
if ([string]::IsNullOrWhiteSpace($root)) {
    $root = Split-Path -Parent $PSScriptRoot           # tools\ -> proje koku
}
$root = [System.IO.Path]::GetFullPath($root)

$updates = $UpdatesDir
if ([string]::IsNullOrWhiteSpace($updates)) {
    $updates = Join-Path $env:USERPROFILE "Documents\GitHub\ANES\Main\Updates"
}
$changelogPath   = Join-Path $updates "ChangeLog.md"
$versionJsonPath = Join-Path $updates "Version.json"
$downloadsDir    = Join-Path $updates "Downloads"

# Yerel bildirim de senkron tutulur (repo icin)
$localManifest = Join-Path $root "Changes\Version.json"
$localChangelog = Join-Path $root "Changes\ChangeLog.md"

$utf8 = New-Object System.Text.UTF8Encoding($false)

# ---------------------------------------------------------------------------
# Yardimcilar
# ---------------------------------------------------------------------------
function Write-JsonFile([string]$path, $obj) {
    $json = $obj | ConvertTo-Json -Depth 12
    $dir = Split-Path -Parent $path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($path, $json + "`r`n", $utf8)
}

function Get-ReleaseType([string]$v, [bool]$isBeta) {
    if ($v -match '(?i)hot[\s-]?fix') { return "Hot Fix" }
    if ($isBeta -or $v -match '(?i)beta') { return "Open Beta" }
    if ($v -match '(?i)alpha') { return "Alpha" }
    return "Stable"
}

# ---------------------------------------------------------------------------
# Baslik
# ---------------------------------------------------------------------------
$prev = "(bilinmiyor)"
if (Test-Path $versionJsonPath) {
    try { $prev = (Get-Content -Raw -Encoding UTF8 $versionJsonPath | ConvertFrom-Json).latest } catch { $prev = "(bilinmiyor)" }
}
if ([string]::IsNullOrWhiteSpace($prev)) { $prev = "(bilinmiyor)" }

Write-Host ""
Write-Host "=========================================================="
Write-Host " ANES AI  -  Surum Yayinlama Araci"
Write-Host "=========================================================="
Write-Host (" Proje kok   : " + $root)
Write-Host (" Updates dir : " + $updates)
Write-Host (" Onceki surum: " + $prev)
Write-Host ""

# ---------------------------------------------------------------------------
# Etkilesimli girdiler
# ---------------------------------------------------------------------------
if (-not $NoAsk) {
    if ([string]::IsNullOrWhiteSpace($Version)) {
        $Version = (Read-Host " Yeni surum   (orn. 1.2.0)").Trim()
    }
    if ([string]::IsNullOrWhiteSpace($Version)) { throw "Surum girilmedi." }

    if ($Notes.Count -eq 0) {
        Write-Host ""
        Write-Host " Degisiklikler (istege bagli). Bitirmek icin bos satiri onaylayin."
        while ($true) {
            $ln = Read-Host "   - "
            if ($null -eq $ln) { break }
            if ([string]::IsNullOrWhiteSpace($ln)) { break }
            $ln = $ln.Trim().TrimStart("-").Trim()
            if (-not [string]::IsNullOrWhiteSpace($ln)) { $Notes += $ln }
        }
    }

    $ans = Read-Host " Bu guncelleme ZORUNLU mu? (e/h)"
    $Mandatory = [bool]($ans -match '^(e|E|y|Y)')

    $ansB = Read-Host " Beta surum mu? (e/h)"
    $Beta = [bool]($ansB -match '^(e|E|y|Y)')

    if ([string]::IsNullOrWhiteSpace($Description)) {
        Write-Host " Surum aciklamasi (tek satir; bos = degisiklikler ozeti)."
        $Description = (Read-Host " Aciklama").Trim()
    }
}

$Version = ($Version -replace '[\\/:*?"<>|\s]', '-').Trim()
if ([string]::IsNullOrWhiteSpace($Version)) { throw "Gecerli bir surum girin." }
if ($Notes.Count -eq 0) { $Notes = @("Performans iyilestirmeleri ve hata duzeltmeleri") }
if ([string]::IsNullOrWhiteSpace($Description)) { $Description = ($Notes -join "; ") }

# ---------------------------------------------------------------------------
# Dagıtim arsivi (.zip)
# ---------------------------------------------------------------------------
$excludeDirs = @('Models', '.venv', '.git', '.backups', '.updater',
                 '__pycache__', 'test', 'Changes', 'build', 'dist',
                 '.pytest_cache', '.idea', '.vscode')
$excludeFiles = @('*.gguf', '*.part', '*.tmp', '*.log', '*.zip')

$archiveUrl = ""
$archiveSha = ""
$archiveName = "ANES-AI-Backend-$Version.zip"

if (-not $SkipArchive) {
    Write-Host ""
    Write-Host "--> Dagıtim arsivi uretiliyor..."
    $stage = Join-Path $env:TEMP ("anes_pub_" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    $count = 0
    Get-ChildItem -Path $root -Recurse -File -Force | ForEach-Object {
        $rel = $_.FullName.Substring($root.Length).TrimStart('\', '/')
        $relF = $rel -replace '\\', '/'
        $top = $relF.Split('/')[0]
        if ($excludeDirs -contains $top) { return }
        foreach ($pat in $excludeFiles) {
            if ($_.Name -like $pat) { return }
        }
        $dest = Join-Path $stage $rel
        $destDir = Split-Path -Parent $dest
        if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Force -Path $destDir | Out-Null }
        Copy-Item -Force $_.FullName $dest
        $count++
        if ($count % 50 -eq 0) { Write-Host ("    ... " + $count + " dosya") }
    }

    $zipPath = Join-Path $updates "Downloads\$archiveName"
    $dlTmp = Join-Path $stage ".."
    $outZip = Join-Path $env:TEMP $archiveName
    if (Test-Path $outZip) { Remove-Item -Force $outZip }
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $outZip -Force
    Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue

    $archiveSha = (Get-FileHash -Algorithm SHA256 $outZip).Hash.ToLower()
    $archiveSizeMB = [math]::Round((Get-Item $outZip).Length / 1MB, 2)

    if (-not (Test-Path $downloadsDir)) { New-Item -ItemType Directory -Force -Path $downloadsDir | Out-Null }
    Copy-Item -Force $outZip $zipPath
    Remove-Item -Force $outZip -ErrorAction SilentlyContinue

    $archiveUrl = "https://github.com/unqownexe/ANES/raw/refs/heads/main/Main/Updates/Downloads/$archiveName"
    Write-Host ("    Arşiv : " + $archiveName + "  (" + $archiveSizeMB + " MB, " + $count + " dosya)")
    Write-Host ("    Sha256: " + $archiveSha)
    Write-Host ("    Kopya : " + $zipPath)
}

# ---------------------------------------------------------------------------
# Version.json guncelle
# ---------------------------------------------------------------------------
$releaseType = Get-ReleaseType $Version ([bool]$Beta)
$channel = if ($Beta) { "beta" } else { "stable" }
$en  = [System.Globalization.CultureInfo]::GetCultureInfo("en-US")
$now = Get-Date
$isoNow = $now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()

# Mevcut bildirimi oku (yoksa iskelet)
$manifest = $null
if (Test-Path $versionJsonPath) {
    try { $manifest = Get-Content -Raw -Encoding UTF8 $versionJsonPath | ConvertFrom-Json } catch { $manifest = $null }
}
$releases = [ordered]@{}
if ($manifest -and $manifest.releases) {
    foreach ($p in $manifest.releases.PSObject.Properties) { $releases[$p.Name] = $p.Value }
}

$newRelease = [ordered]@{
    version      = $Version
    channel      = $channel
    releaseType  = $releaseType
    beta         = [bool]$Beta
    mandatory    = [bool]$Mandatory
    minFrom      = "0.0.0"
    title        = ($Notes | Select-Object -First 1)
    description  = $Description
    releasedAt   = $isoNow
    timestamp    = [int64]$ts
    changes      = @($Notes)
    archive      = $archiveUrl
    sha256       = $archiveSha
    files        = @()
    postUpdate   = [ordered]@{ commands = @(); pip = @(); message = "" }
}
$releases[$Version] = $newRelease

$outManifest = [ordered]@{
    schema           = 2
    channel          = $channel
    latest           = $Version
    minimumSupported = if ($manifest.minimumSupported) { $manifest.minimumSupported } else { "0.0.0" }
    releasedAt       = $isoNow
    generatedAt      = [int64]$ts
    changelog        = "ChangeLog.md"
    repository       = [ordered]@{ owner = "unqownexe"; name = "ANES"; branch = "main" }
    releases         = $releases
}
Write-JsonFile $versionJsonPath $outManifest
Write-JsonFile $localManifest $outManifest
Write-Host ""
Write-Host ("    Version.json  -> " + $Version + "  (zorunlu=" + ([string]$Mandatory).ToLower() + ", beta=" + ([string]$Beta).ToLower() + ")")

# ---------------------------------------------------------------------------
# ChangeLog.md guncelle (yeni bolum en uste)
# ---------------------------------------------------------------------------
$dateShort = $now.ToString("dd MMM yyyy", $en)
$clTitle = "## $Version $releaseType ($dateShort)"
if ($releaseType -eq "Stable") { $clTitle = "## $Version ($dateShort)" }

$oldBody = ""
if (Test-Path $changelogPath) {
    $txt = [System.IO.File]::ReadAllText($changelogPath)
    $txt = $txt.TrimStart([char]0xFEFF)
    $i = $txt.IndexOf("`n## ")
    if ($i -ge 0) { $oldBody = $txt.Substring($i + 1).TrimStart("`r", "`n") }
    else { $i2 = $txt.IndexOf("## "); if ($i2 -ge 0) { $oldBody = $txt.Substring($i2) } }
}
$cl = @()
$cl += "# ANES AI - Changelog"
$cl += ""
$cl += $clTitle
$cl += ""
$cl += "Kanal: **$channel** · Zorunlu: " + $(if ($Mandatory) { "evet" } else { "hayır" })
$cl += ""
$cl += "Eklenenler & Düzeltilenler:"
foreach ($n in $Notes) { $cl += "  - $n" }
$cl += ""
if (-not [string]::IsNullOrWhiteSpace($oldBody)) { $cl += $oldBody.TrimStart("`r", "`n") }
[System.IO.File]::WriteAllText($changelogPath, (($cl -join "`r`n") + "`r`n"), $utf8)
[System.IO.File]::WriteAllText($localChangelog, (($cl -join "`r`n") + "`r`n"), $utf8)
Write-Host ("    ChangeLog.md  -> " + $Version + " (" + $dateShort + ")")

Write-Host ""
Write-Host (" OK: " + $prev + "  ->  " + $Version)
Write-Host ""
Write-Host " Yapilacaklar:"
Write-Host ("   1) '" + $downloadsDir + "' icindeki yeni arsivi GitHub'a push edin.")
Write-Host "   2) Changes\Version.json ve Changes\ChangeLog.md dosyalarini push edin."
Write-Host ""
exit 0
