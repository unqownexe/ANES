@echo off
REM ============================================================
REM  ANES AI - Ilk Kurulum (tek tik)
REM  - Bos klasorde bile calisir: dosyalari GitHub'dan indirir
REM  - Python + .venv + bagimliliklari kurar
REM  - Varsayilan modeli (istege bagli) indirir
REM  - Her adim anlik ilerleme gosterir
REM ============================================================
setlocal enableextensions
cd /d "%~dp0"
title ANES AI - Ilk Kurulum
chcp 65001 >nul

echo Kurulum baslatiliyor, lutfen bekleyin...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\first-install.ps1" %*
set "RC=%errorlevel%"

echo.
if not "%RC%"=="0" (
    echo [!] Kurulum hata ile bitti ^(kod: %RC%^).
) else (
    echo [OK] Kurulum tamamlandi. Baslatmak icin start.bat calistirin.
)
echo.
pause
endlocal
exit /b %RC%
