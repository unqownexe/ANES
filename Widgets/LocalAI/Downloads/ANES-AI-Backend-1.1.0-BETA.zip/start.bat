@echo off
REM ============================================================
REM  ANES AI Backend - Baslatici
REM  Port: 8493  |  Acilista 30 dk'lik guncelleme kontrolu baslar
REM ============================================================
setlocal enableextensions
title ANES AI Backend - Port 8493
chcp 65001 >nul
cd /d "%~dp0"

REM Sanal ortam varsa kullan
if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

echo [i] Python: %PY%
"%PY%" --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python bulunamadi. Lutfen once FirstInstall.cmd calistirin.
    pause
    exit /b 1
)

REM Bagimlilik kontrolu
"%PY%" -c "import fastapi, uvicorn, pydantic" >nul 2>&1
if errorlevel 1 (
    echo [!] Bagimliliklar eksik. tools\install.bat calistiriliyor...
    call tools\install.bat --no-pause
)

echo.
echo ============================================================
echo   ANES AI Backend baslatiliyor...
echo   Adres : http://127.0.0.1:8493
echo   Docs  : http://127.0.0.1:8493/docs
echo   Not   : Arka planda 30 dk'da bir guncelleme kontrol edilir.
echo ============================================================
echo.

"%PY%" run.py %*
endlocal
