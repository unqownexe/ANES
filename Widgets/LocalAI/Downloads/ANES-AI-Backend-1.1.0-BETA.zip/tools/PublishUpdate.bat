@echo off
REM ============================================================
REM  ANES AI - Surum Yayinlama Araci (tools\PublishUpdate.bat)
REM  Ciktilar: Documents\GitHub\ANES\Widgets\LocalAI\
REM    - Version.json, ChangeLog.md, Downloads\*.zip
REM  Not: Surum adinda "beta" gecerse OTOMATIK beta sayilir.
REM ============================================================
setlocal enableextensions
chcp 65001 >nul
cd /d "%~dp0.."
title ANES AI - Surum Yayinlama

if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

"%PY%" --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python bulunamadi.
    pause
    exit /b 1
)

"%PY%" "tools\publish_update.py" %*
set "RC=%errorlevel%"

echo.
if "%RC%"=="0" (
    echo [OK] Surum yayinlandi.
) else (
    echo [!] Islem tamamlanmadi ^(kod: %RC%^).
)
echo.
pause
endlocal
exit /b %RC%
