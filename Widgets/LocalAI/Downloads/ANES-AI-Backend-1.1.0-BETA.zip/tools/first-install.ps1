# ANES AI — Ilk Kurulum (First Install)
# ============================================================
# "FirstInstall.cmd" tarafindan cagrilir.
#   - Bu klasor bos/eksikse: GitHub'dan tum dosyalari indirir ve acar
#   - Python yoksa: indirir ve sessizce kurar
#   - .venv olusturur ve bagimliliklari kurar  (install.bat)
#   - Varsayilan modeli (istege bagli) indirir
# Her adim ANLIK ilerleme gosterir (yuzde + durum).
#
# Dogrudan:
#   powershell -ExecutionPolicy Bypass -File tools\first-install.ps1
# Sessiz:
#   .\tools\first-install.ps1 -NoAsk -Model none
#
param(
    [string]$Repo = "unqownexe/ANES",
    [string]$Branch = "main",
    [ValidateSet("none", "low", "medium", "high", "ultra_high", "ask")]
    [string]$Model = "ask",
    [switch]$NoAsk,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::InputEncoding  = [System.Text.Encoding]::UTF8
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
} catch {}

$root = Split-Path -Parent $PSScriptRoot          # tools\ -> proje koku
Set-Location $root

$TOTAL_STEPS = 4
$script:step = 0

# ---------------------------------------------------------------------------
# Gorsel yardimcilar
# ---------------------------------------------------------------------------
function Write-Head([string]$text) {
    Write-Host ""
    Write-Host ("=" * 62) -ForegroundColor Cyan
    Write-Host ("  " + $text) -ForegroundColor White
    Write-Host ("=" * 62) -ForegroundColor Cyan
}
function Write-Step([string]$text) {
    $script:step++
    Write-Host ""
    Write-Host ("[$($script:step)/$TOTAL_STEPS] " + $text) -ForegroundColor Yellow
}
function Write-Ok([string]$t)   { Write-Host ("    [OK] " + $t)   -ForegroundColor Green }
function Write-Info([string]$t) { Write-Host ("    [i] "  + $t)   -ForegroundColor Gray }
function Write-Warn([string]$t) { Write-Host ("    [!] "  + $t)   -ForegroundColor DarkYellow }

# Ilerlemeli indirme (yuzde)
function Get-File([string]$url, [string]$dest, [string]$label) {
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.UserAgent = "ANES-FirstInstall/1.0"
    $req.Timeout = 30000
    $resp = $req.GetResponse()
    $total = $resp.ContentLength
    $in = $resp.GetResponseStream()
    $dir = Split-Path -Parent $dest
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $out = [System.IO.File]::Create($dest)
    $buf = New-Object byte[] 262144
    $got = 0
    try {
        while (($read = $in.Read($buf, 0, $buf.Length)) -gt 0) {
            $out.Write($buf, 0, $read)
            $got += $read
            if ($total -gt 0) {
                $pct = [int](100 * $got / $total)
                $mb = [math]::Round($got / 1MB, 1)
                $tot = [math]::Round($total / 1MB, 1)
                Write-Progress -Activity $label -Status "$pct%  ($mb/$tot MB)" -PercentComplete $pct
            } else {
                Write-Progress -Activity $label -Status ("$([math]::Round($got/1MB,1)) MB") -PercentComplete 0
            }
        }
    } finally {
        $out.Close(); $in.Close()
        Write-Progress -Activity $label -Completed
    }
    return $dest
}

function Test-RepoPresent() {
    return (Test-Path (Join-Path $root "app\main.py")) -and (Test-Path (Join-Path $root "run.py"))
}

# ---------------------------------------------------------------------------
# Baslik
# ---------------------------------------------------------------------------
Clear-Host
Write-Head "ANES AI Backend - Ilk Kurulum"
Write-Host ("  Hedef klasor : " + $root)
Write-Host ("  Kaynak depo  : " + $Repo + " (" + $Branch + ")")
Write-Host ""

# ---------------------------------------------------------------------------
# 1) Proje dosyalari
# ---------------------------------------------------------------------------
Write-Step "Proje dosyalari hazirlaniyor"
if ((Test-RepoPresent) -and (-not $Force)) {
    Write-Ok "Dosyalar zaten mevcut (indirme atlandi)."
} else {
    Write-Info "GitHub'dan indiriliyor: $Repo/$Branch"
    $zipUrl = "https://github.com/$Repo/archive/refs/heads/$Branch.zip"
    $tmpZip = Join-Path $env:TEMP ("anes_repo_" + [guid]::NewGuid().ToString("N") + ".zip")
    try {
        Get-File $zipUrl $tmpZip "Depo paketi indiriliyor" | Out-Null
    } catch {
        Write-Warn "Indirme basarisiz: $($_.Exception.Message)"
        throw "Depo indirilemedi. Internet baglantinizi kontrol edin."
    }
    $szMB = [math]::Round((Get-Item $tmpZip).Length / 1MB, 2)
    Write-Ok "Indirildi ($szMB MB)."

    Write-Info "Arsiv acilyor..."
    $ex = Join-Path $env:TEMP ("anes_repo_" + [guid]::NewGuid().ToString("N"))
    if (Test-Path $ex) { Remove-Item -Recurse -Force $ex }
    Expand-Archive -Path $tmpZip -DestinationPath $ex -Force
    $inner = Get-ChildItem -Path $ex -Directory | Select-Object -First 1
    if (-not $inner) { throw "Arsiv icerigi bulunamadi." }
    Write-Info "Dosyalar kopyalaniyor..."
    Copy-Item -Path (Join-Path $inner.FullName '*') -Destination $root -Recurse -Force
    Remove-Item -Recurse -Force $ex -ErrorAction SilentlyContinue
    Remove-Item -Force $tmpZip -ErrorAction SilentlyContinue
    Write-Ok "Proje dosyalari yerlestirildi."
}

# ---------------------------------------------------------------------------
# 2) Bagimliliklar (install.bat: Python + venv + pip)
# ---------------------------------------------------------------------------
Write-Step "Bagimliliklar kuruluyor (Python + .venv + pip)"
$install = Join-Path $root "tools\install.bat"
if (-not (Test-Path $install)) {
    throw "tools\install.bat bulunamadi. Depo dosyalari eksik olabilir."
}
Write-Info "tools\install.bat calistiriliyor - bu adim uzun surebilir (canli cikti):"
Write-Host ""
& cmd /c "`"$install`" --no-pause"

$venvPy = Join-Path $root ".venv\Scripts\python.exe"
if (Test-Path $venvPy) { Write-Ok ".venv hazir: .venv\Scripts\python.exe" }
else { Write-Warn ".venv olusmadi; sistem Python'u kullanilacak." }

# ---------------------------------------------------------------------------
# 3) Varsayilan model (istege bagli)
# ---------------------------------------------------------------------------
Write-Step "Varsayilan model"
$modelsJson = Join-Path $root "config\Models.json"
$doModel = $false
if ($Model -eq "ask" -and -not $NoAsk) {
    $ans = Read-Host " Varsayilan modeli (~2 GB, 'low') simdi indirilsin mi? (e/h)"
    $doModel = [bool]($ans -match '^(e|E|y|Y)')
    $tier = "low"
} elseif ($Model -ne "none") {
    $doModel = $true
    $tier = $Model
} else {
    $tier = "low"
}

if ($doModel -and (Test-Path $modelsJson)) {
    try {
        $mj = Get-Content -Raw -Encoding UTF8 $modelsJson | ConvertFrom-Json
        $entry = $mj.$tier
        if ($entry) {
            $dest = Join-Path $root ("Models\" + $entry.filename)
            if ((Test-Path $dest) -and (-not $Force)) {
                Write-Ok ("Model zaten mevcut: " + $entry.filename)
            } else {
                Write-Info ("Indiriliyor: " + $entry.model + " / " + $entry.details)
                Get-File $entry.download_link $dest ("Model indiriliyor (" + $entry.filename + ")") | Out-Null
                $mb = [math]::Round((Get-Item $dest).Length / 1MB, 1)
                Write-Ok "Model indirildi ($mb MB): Models\$($entry.filename)"
            }
        } else {
            Write-Warn "Model tier bulunamadi: $tier"
        }
    } catch {
        Write-Warn "Model indirilemedi: $($_.Exception.Message)"
    }
} elseif ($doModel) {
    Write-Warn "Models.json bulunamadi; model adimi atlandi."
} else {
    Write-Info "Model indirme atlandi (daha sonra bakend /v1/models/download ile yapilabilir)."
}

# ---------------------------------------------------------------------------
# 4) Ozet
# ---------------------------------------------------------------------------
Write-Step "Kurulum ozeti"
Write-Host ""
Write-Host "  ------------------------------------------------------------" -ForegroundColor Cyan
Write-Host "   KURULUM TAMAMLANDI" -ForegroundColor Green
Write-Host "  ------------------------------------------------------------" -ForegroundColor Cyan
if (Test-Path $venvPy) { Write-Host ("   Python   : " + $venvPy) }
Write-Host "   Baslat   : start.bat"
Write-Host "   Adres    : http://127.0.0.1:8493"
Write-Host "   Docs     : http://127.0.0.1:8493/docs"
Write-Host "   Guncelle : update.bat"
Write-Host "  ------------------------------------------------------------" -ForegroundColor Cyan
Write-Host ""
exit 0
