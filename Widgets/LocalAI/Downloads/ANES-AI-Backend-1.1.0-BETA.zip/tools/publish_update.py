#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANES AI — Sürüm Yayınlama Aracı (UTF-8, Türkçe karakter desteği).

Kullanım:
    tools\\PublishUpdate.bat            (etkileşimli)
    python tools\\publish_update.py      (doğrudan)

    # Sessiz / otomasyon:
    python tools\\publish_update.py --version 1.2.0-BETA --notes "x" "y" --no-ask
    python tools\\publish_update.py --dry-run --version 1.2.0

ÇIKTILAR (yalnızca bu klasöre yazar):
    Documents\\GitHub\\ANES\\Widgets\\LocalAI\\
        ├── Version.json
        ├── ChangeLog.md
        └── Downloads\\
              └── ANES-AI-Backend-<sürüm>.zip

KURALLAR:
  • Sürüm adında "beta" (büyük/küçük harf fark etmez) geçiyorsa sürüm
    OTOMATİK olarak beta kabul edilir; ayrıca sorulmaz.
  • Tüm dosyalar UTF-8 (BOM'suz) yazılır; Türkçe karakterler bozulmaz.
  • Hedef klasörde başka bir programın bildirimi varsa (`VersionDetails`)
    araç DURUR ve hiçbir dosyaya dokunmaz.
  • Yazmadan önce mevcut dosyalar `.bak` olarak yedeklenir.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Konsol UTF-8 (Windows cp1254 Türkçe karakterleri bozar)
# ---------------------------------------------------------------------------
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        pass

# ---------------------------------------------------------------------------
# Yollar
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent      # tools\ -> proje kökü
DEFAULT_TARGET = Path(os.path.expanduser(
    "~")) / "Documents" / "GitHub" / "ANES" / "Widgets" / "LocalAI"

RAW_BASE = ("https://github.com/unqownexe/ANES/raw/refs/heads/main/"
            "Widgets/LocalAI/Downloads")

# Arşive girmeyecek klasör / dosyalar
EXCLUDE_DIRS = {
    "Models", ".venv", ".git", ".backups", ".updater", "__pycache__",
    "test", "Changes", "build", "dist", ".pytest_cache", ".idea", ".vscode",
    "tools/__pycache__",
}
EXCLUDE_SUFFIXES = {".gguf", ".part", ".tmp", ".log", ".zip", ".pyc"}


def c(code: str, s: str) -> str:
    if sys.stdout.isatty() and os.environ.get("NO_COLOR") is None:
        return f"\x1b[{code}m{s}\x1b[0m"
    return s


def bold(s): return c("1", s)
def dim(s): return c("38;5;245", s)
def cyan(s): return c("36", s)
def green(s): return c("32", s)
def yellow(s): return c("33", s)
def red(s): return c("31", s)


# ---------------------------------------------------------------------------
# Yardımcılar
# ---------------------------------------------------------------------------
def write_text(path: Path, text: str, dry: bool) -> None:
    print(dim(f"    yazılacak: {path}"))
    if dry:
        print(yellow("    [dry-run] atlandı"))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        shutil.copy2(path, path.with_suffix(path.suffix + ".bak"))
    # UTF-8, BOM yok, \r\n
    with path.open("w", encoding="utf-8", newline="\r\n") as fh:
        fh.write(text)


def release_type(version: str) -> str:
    """Sürüm adından yayın türünü çıkarır."""
    v = version.lower()
    if re.search(r"hot[\s._-]?fix", v):
        return "Hot Fix"
    if "beta" in v:
        return "Open Beta"
    if "alpha" in v:
        return "Alpha"
    return "Stable"


def is_beta(version: str) -> bool:
    """Sürüm adında beta geçiyor mu? (büyük/küçük harf fark etmez)."""
    return "beta" in version.lower()


def own_manifest(path: Path) -> bool:
    """Dosya ANES AI'ya mı ait? (başka programınkini ezmemek için)."""
    if not path.exists():
        return True                      # yoksa biz oluşturacağız
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:  # noqa: BLE001
        return False
    if "releases" in data:
        return True                      # bizim şemamız
    if "VersionDetails" in data or "lastVersion" in data:
        return False                     # Webtelya ANES şeması
    return False


def build_archive(root: Path, dest: Path) -> tuple[int, float]:
    """Dizin ağacını .zip olarak paketler. (dosya_sayısı, MB) döndürür."""
    count = 0
    tmp = Path(tempfile.gettempdir()) / f"anes_pub_{int(time.time())}.zip"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            parts = rel.parts
            if any(p in EXCLUDE_DIRS for p in parts[:-1]) or parts[0] in EXCLUDE_DIRS:
                continue
            if path.suffix.lower() in EXCLUDE_SUFFIXES:
                continue
            zf.write(path, rel.as_posix())
            count += 1
            if count % 50 == 0:
                print(dim(f"    ... {count} dosya"))
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(tmp), str(dest))
    return count, round(dest.stat().st_size / 1024 / 1024, 2)


def sha256_of(path: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Ana akış
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--root", default=str(BASE_DIR))
    ap.add_argument("--target", default=str(DEFAULT_TARGET))
    ap.add_argument("--version", default="")
    ap.add_argument("--notes", nargs="*", default=[])
    ap.add_argument("--description", default="")
    ap.add_argument("--mandatory", action="store_true")
    ap.add_argument("--no-beta", action="store_true",
                    help="Sürüm adında beta geçse bile beta sayma")
    ap.add_argument("--no-ask", action="store_true")
    ap.add_argument("--skip-archive", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    target = Path(args.target).resolve()
    version_json = target / "Version.json"
    changelog = target / "ChangeLog.md"
    downloads = target / "Downloads"

    print()
    print("=" * 62)
    print(bold("  ANES AI  ·  Sürüm Yayınlama Aracı"))
    print("=" * 62)
    print(f"  Proje kökü   : {dim(str(root))}")
    print(f"  Hedef klasör : {cyan(str(target))}")
    print(f"  Çıktı URL    : {dim(RAW_BASE)}")
    print()

    # --- Güvenlik ---
    if not own_manifest(version_json):
        print(red("!! DURDURULDU"))
        print(red(f"   {version_json}"))
        print(red("   başka bir programa ait görünüyor (içinde 'VersionDetails' var)."))
        print(yellow("   Bu dosya EZİLMEYECEK. Farklı bir --target verin."))
        print()
        return 2

    prev = "(bilinmiyor)"
    if version_json.exists():
        try:
            prev = json.loads(version_json.read_text(encoding="utf-8-sig")).get("latest", prev)
        except Exception:  # noqa: BLE001
            pass
    print(f"  Önceki sürüm : {prev}")
    print()

    # --- Girdiler ---
    version = (args.version or "").strip()
    notes = list(args.notes)
    mandatory = bool(args.mandatory)
    description = (args.description or "").strip()

    if not args.no_ask:
        if not version:
            version = input("  Yeni sürüm (örn. 1.2.0 veya 1.2.0-BETA): ").strip()
        if not version:
            print(red("  Sürüm girilmedi."))
            return 1

        if not notes:
            print()
            print("  Değişiklikler (bitirmek için boş satır):")
            while True:
                try:
                    ln = input("    - ").strip()
                except EOFError:
                    break
                if not ln:
                    break
                notes.append(ln.lstrip("-").strip())

        if not args.mandatory:
            ans = input("  Bu güncelleme ZORUNLU mu? (e/h): ").strip().lower()
            mandatory = ans.startswith(("e", "y"))

        # BETA sorusu YOK: sürüm adından otomatik algılanır.

        if not description:
            description = input("  Açıklama (boş = değişiklik özeti): ").strip()

    # Sürüm adını güvenli hale getir
    version = re.sub(r'[\\/:*?"<>|\s]+', "-", version).strip("-")
    if not version:
        print(red("  Geçerli bir sürüm girin."))
        return 1

    if not notes:
        notes = ["Performans iyileştirmeleri ve hata düzeltmeleri"]
    if not description:
        description = "; ".join(notes)

    # --- BETA otomatik algılama ---
    beta = is_beta(version) and not args.no_beta
    rtype = release_type(version)
    channel = "beta" if beta else "stable"
    if beta:
        print(green(f"  ✓ '{version}' adında BETA geçiyor → kanal: beta (otomatik)"))
    else:
        print(dim(f"  Kanal: {channel}"))

    # --- Arşiv ---
    archive_url = ""
    archive_sha = ""
    archive_name = f"ANES-AI-Backend-{version}.zip"
    if not args.skip_archive:
        print()
        print("--> Dağıtım arşivi üretiliyor...")
        dest_zip = downloads / archive_name
        count, mb = build_archive(root, dest_zip if not args.dry_run
                                  else Path(tempfile.gettempdir()) / archive_name)
        archive_sha = sha256_of(dest_zip if not args.dry_run
                                else Path(tempfile.gettempdir()) / archive_name)
        archive_url = f"{RAW_BASE}/{archive_name}"
        print(green(f"    Arşiv  : {archive_name}  ({mb} MB, {count} dosya)"))
        print(dim(f"    Sha256 : {archive_sha}"))
        print(dim(f"    Kopya  : {dest_zip}"))

    # --- Version.json ---
    now_utc = datetime.now(timezone.utc)
    iso_now = now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
    ts = int(time.time() * 1000)

    releases = {}
    if version_json.exists():
        try:
            releases = json.loads(
                version_json.read_text(encoding="utf-8-sig")).get("releases", {})
        except Exception:  # noqa: BLE001
            releases = {}

    releases[version] = {
        "version": version,
        "channel": channel,
        "releaseType": rtype,
        "beta": beta,
        "mandatory": mandatory,
        "minFrom": "0.0.0",
        "title": notes[0],
        "description": description,
        "releasedAt": iso_now,
        "timestamp": ts,
        "changes": notes,
        "archive": archive_url,
        "sha256": archive_sha,
        "files": [],
        "postUpdate": {"commands": [], "pip": [], "message": ""},
    }

    manifest = {
        "schema": 2,
        "channel": channel,
        "latest": version,
        "minimumSupported": "0.0.0",
        "releasedAt": iso_now,
        "generatedAt": ts,
        "changelog": "ChangeLog.md",
        "repository": {"owner": "unqownexe", "name": "ANES", "branch": "main"},
        "releases": releases,
    }
    print()
    write_text(version_json, json.dumps(manifest, indent=4, ensure_ascii=False) + "\n",
               args.dry_run)
    print(green(f"    Version.json  → {version}  "
                f"(zorunlu={str(mandatory).lower()}, beta={str(beta).lower()})"))

    # --- ChangeLog.md ---
    old_body = ""
    if changelog.exists():
        try:
            txt = changelog.read_text(encoding="utf-8-sig")
            m = re.search(r"^## ", txt, re.MULTILINE)
            if m:
                old_body = txt[m.start():].rstrip()
        except Exception:  # noqa: BLE001
            pass

    date_short = now_utc.strftime("%d %b %Y")
    title = f"## {version} ({date_short})" if rtype == "Stable" \
        else f"## {version} {rtype} ({date_short})"

    lines = ["# ANES AI - Changelog", "", title, "",
             f"Kanal: **{channel}** · Zorunlu: {'evet' if mandatory else 'hayır'}",
             "", "Eklenenler & Düzeltilenler:"]
    lines += [f"  - {n}" for n in notes]
    lines.append("")
    if old_body:
        lines.append(old_body)
    write_text(changelog, "\n".join(lines) + "\n", args.dry_run)
    print(green(f"    ChangeLog.md  → {version} ({date_short})"))

    print()
    print(bold(f" OK: {prev}  →  {version}") +
          (red("  [BETA]") if beta else "") +
          (red("  [ZORUNLU]") if mandatory else ""))
    if args.dry_run:
        print(yellow(" (DRY-RUN: hiçbir dosya yazılmadı)"))
    print()
    print(" Yapılacaklar:")
    print(f"   1) '{downloads}' içindeki arşivi GitHub'a push edin.")
    print("   2) Widgets/LocalAI/Version.json ve ChangeLog.md dosyalarını push edin.")
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())