@echo off
REM ============================================================
REM  ANES AI - Guncelleme Yoneticisi (proje koku)
REM  Rakamla menu: 1 kontrol | 2 indir/uygula | 3 ayarlar | ...
REM  Dogrudan   : update.bat check | apply | beta on | auto on
REM ============================================================
setlocal enableextensions
title ANES AI - Guncelleme Yoneticisi
chcp 65001 >nul
cd /d "%~dp0"

REM Sanal ortam varsa kullan
if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

"%PY%" --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python bulunamadi. Lutfen once FirstInstall.cmd calistirin.
    pause
    exit /b 1
)

"%PY%" "updater\update.py" %*
endlocal
