# ANES AI — Güncelleme Yöneticisi

Bu klasör (`updater/`) güncelleme **CLI'sini** barındırır. Asıl çekirdek kod
[`app/updater.py`](../app/updater.py), ayarlar ise [`config/Updater.json`](../config/Updater.json)
dosyasındadır.

Sistem, ANES AI Backend'ini GitHub deposundan (`unqownexe/ANES`) otomatik
günceller. Başka bir cihazdaki kurulum, siz depoya yeni bir sürüm bildirimi
(`Version.json`) eklediğinizde bunu algılar ve **isteğe bağlı** ya da
**zorunlu** olarak indirir.

## Klasör İçeriği

| Dosya | Rol |
|-------|-----|
| [`update.py`](update.py) | Etkileşimli CLI yöneticisi (rakamla menü) |
| [`README.md`](README.md) | Bu doküman |

İlgili dosyalar:

| Yol | Rol |
|-----|-----|
| [`../config/Updater.json`](../config/Updater.json) | İstemci yapılandırması |
| [`../update.bat`](../update.bat) | CLI başlatıcı (proje kökü) |
| [`../app/updater.py`](../app/updater.py) | Güncelleme çekirdeği + 30 dk servisi |
| [`../app/main.py`](../app/main.py) | HTTP uç noktaları |

---

## Kullanım

Proje kökünden:

```bat
update.bat
```

Menüde rakam girin:

```
1  Güncellemeleri kontrol et
2  Güncellemeyi indir / uygula
3  Ayarlar  (kanal · beta · otomatik)
4  Sürüm geçmişi (ChangeLog)
5  Durum
0  Çıkış
```

Doğrudan komutlar:

```bat
update.bat check            REM güncelleme var mı?
update.bat apply            REM indir ve uygula
update.bat beta on          REM beta sürümlerini dahil et
update.bat channel beta     REM aktif kanalı beta yap
update.bat auto on          REM otomatik kontrolü aç
update.bat status           REM durum özeti
```

---

## Nasıl Çalışır?

1. **Bildirim** — GitHub'daki `Widgets/LocalAI/Version.json` indirilir.
2. **Karşılaştırma** — Yerel `installedVersion` ile uzak sürümler karşılaştırılır.
   Beta sürümler yalnızca `allowBeta = true` ise dikkate alınır.
3. **Seçim** — En son uygun sürüm hedeflenir. **Zorunlu (mandatory)** güncelleme
   varsa adım adım ilerlenir.
4. **İndirme** — `archive` (.zip) veya `files` (tek tek dosya) indirilir,
   `sha256` ile doğrulanır.
5. **Yedek** — Uygulamadan önce dosyalar `.backups/<sürüm>-<zaman>/` altına kopyalanır.
6. **Post-update** — Gerekli terminal / pip komutları çalıştırılır.
7. **Kayıt** — `installedVersion` güncellenir; `Changes/Version.json` ve
   `Changes/ChangeLog.md` tazelenir.

> **Güvenlik:** `Models/`, `.venv/`, `.git/`, `.backups/`, `.updater/` gibi yollar
> güncellemelerce **asla** üzerine yazılmaz.

---

## Arka Plan Kontrolü

`start.bat` ile backend başlatıldığında `UpdateService` otomatik çalışır:
açılıştan ~15 sn sonra ve ardından **30 dakikada bir** kontrol yapar.
Loglar `.updater/updater.log` dosyasına yazılır.

Kapatmak için: `ANES_UPDATE_AUTOSTART=0` ortam değişkeni ya da
[`config/Updater.json`](../config/Updater.json) içinde `autoUpdate.enabled = false`.

---

## Yapılandırma (`config/Updater.json`)

| Alan | Açıklama |
|------|----------|
| `installedVersion` | Bu cihazda kurulu sürüm |
| `repo.owner` / `repo.name` / `repo.branch` | GitHub deposu |
| `repo.manifestPaths` | `Version.json`'un aranacağı yollar (sırayla) |
| `channels.current` | `stable` veya `beta` |
| `channels.allowBeta` | Beta sürümler indirilsin mi |
| `autoUpdate.enabled` | Arka plan kontrolü açık mı |
| `autoUpdate.checkIntervalMinutes` | Kontrol aralığı (varsayılan **30**) |
| `autoUpdate.applyAutomatically` | Onay sormadan otomatik uygula |
| `update.strategy` | `auto` · `archive` · `files` |
| `update.backup` | Güncelleme öncesi yedek al |
| `update.restartAfterUpdate` | Uygulamadan sonra yeniden başlat |
| `update.restartCommand` | Yeniden başlatma komutu (`start.bat`) |
| `postUpdate.commands` | Güncelleme sonrası terminal komutları |
| `postUpdate.pip` | Kurulacak ek pip paketleri |

### Örnek: güncelleme sonrası komut

```json
"postUpdate": {
    "commands": ["start.bat --no-pause"],
    "pip": ["psutil>=5.9.0"],
    "message": "Güncelleme tamamlandı."
}
```

---

## Sürüm Yayınlama

```bat
tools\PublishUpdate.bat
```

Ayrıntı: [`tools/publish-update.ps1`](../tools/publish-update.ps1)

---

## HTTP Uç Noktaları

| Yöntem | Yol | Açıklama |
|--------|-----|----------|
| GET | `/v1/update/check` | Güncelleme denetle |
| POST | `/v1/update/apply?target=1.2.0&force=false` | İndir ve uygula |
| GET | `/v1/update/status` | Servis + sürüm durumu |
| GET | `/v1/update/version` | Yerel sürüm özeti |
| POST | `/v1/update/channel?channel=beta&allow_beta=true` | Kanal/beta ayarı |
| POST | `/v1/update/settings?interval_minutes=60&auto_enabled=true` | Otomatik ayarlar |

---

## Yedekten Geri Dönme

Yedekler `.backups/` altındadır. Geri dönmek için ilgili klasördeki dosyaları
kök dizine kopyalayın ve [`config/Updater.json`](../config/Updater.json) içindeki
`installedVersion` değerini eski sürüme alın.
