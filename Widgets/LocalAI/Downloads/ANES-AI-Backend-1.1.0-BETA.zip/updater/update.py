#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ANES AI — Güncelleme Yöneticisi (etkileşimli CLI).

Bu dosya proje kökündeki `updater/` klasöründedir.

Rakam girerek menüyü kullanırsınız:

    1  Güncellemeleri kontrol et
    2  Güncellemeyi indir / uygula
    3  Kanal ve otomatik güncelleme ayarları
    4  Sürüm geçmişi (ChangeLog)
    5  Durum
    0  Çıkış

Doğrudan komutlar da desteklenir (menüye girmeden):
    python updater\\update.py check
    python updater\\update.py apply
    python updater\\update.py beta on
    python updater\\update.py auto on
    python updater\\update.py channel beta
    python updater\\update.py status

Kısayol: proje kökünden `update.bat` çağırabilirsiniz.
"""

from __future__ import annotations

import os
import sys

# Proje kökünü sys.path'e ekle (bir üst klasör) ki `app` paketi bulunsun.
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

from app import updater as up  # noqa: E402

# ---------------------------------------------------------------------------
# Renkler
# ---------------------------------------------------------------------------
_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def c(code: str, s: str) -> str:
    return f"\x1b[{code}m{s}\x1b[0m" if _COLOR else s


def bold(s): return c("1", s)
def dim(s): return c("38;5;245", s)
def cyan(s): return c("36", s)
def green(s): return c("32", s)
def yellow(s): return c("33", s)
def red(s): return c("31", s)
def magenta(s): return c("35", s)
def blue(s): return c("34", s)


def clear():
    if _COLOR:
        os.system("cls" if os.name == "nt" else "clear")


def line(text: str = "", color=None) -> None:
    print(color(text) if color else text)


def rule():
    line(dim("─" * 62))


# ---------------------------------------------------------------------------
# Görselleştirme
# ---------------------------------------------------------------------------
def banner() -> None:
    u = up.updater
    clear()
    line()
    line(bold(cyan("  ╭────────────────────────────────────────────────────────╮")))
    line(bold(cyan("  │        ANES AI · Otomatik Güncelleme Yöneticisi         │")))
    line(bold(cyan("  ╰────────────────────────────────────────────────────────╯")))
    line(f"  {dim('Kurulu sürüm :')} {green(u.current_version)}")
    line(f"  {dim('Kanal         :')} {yellow(u.channel)}"
         f"    {dim('beta izni:')} "
         f"{(green('açık') if u.allow_beta else red('kapalı'))}")
    auto = u.config.get("autoUpdate", {})
    line(f"  {dim('Otomatik      :')} "
         f"{(green('açık') if auto.get('enabled') else red('kapalı'))}"
         f"    {dim('aralık:')} {auto.get('checkIntervalMinutes', 30)} dk"
         f"    {dim('otomatik uygula:')} "
         f"{('evet' if auto.get('applyAutomatically') else 'hayır')}")
    line(f"  {dim('Depo          :')} "
         f"{up.updater.config.get('repo', {}).get('owner')}/"
         f"{up.updater.config.get('repo', {}).get('name')}")
    line()


def menu() -> None:
    rule()
    line(f"  {magenta('1')}  {bold('Güncellemeleri kontrol et')}")
    line(f"  {magenta('2')}  {bold('Güncellemeyi indir / uygula')}")
    line(f"  {magenta('3')}  {bold('Ayarlar')}  {dim('(kanal · beta · otomatik)')}")
    line(f"  {magenta('4')}  {bold('Sürüm geçmişi')}  {dim('(ChangeLog)')}")
    line(f"  {magenta('5')}  {bold('Durum')}")
    line(f"  {magenta('0')}  {dim('Çıkış')}")
    rule()


# ---------------------------------------------------------------------------
# Eylemler
# ---------------------------------------------------------------------------
def action_check() -> up.UpdateResult:
    line()
    line(dim("  Uzak bildirim kontrol ediliyor..."))
    res = up.updater.check()
    if res.status == "error":
        line(red(f"  ✗ {res.message}"))
    elif res.status == "uptodate":
        line(green(f"  ✓ {res.message}"))
    else:
        color = red if res.mandatory else yellow
        tag = " [ZORUNLU]" if res.mandatory else ""
        btag = " [beta]" if res.beta else ""
        line(color(f"  ▲ {res.message}{tag}{btag}"))
        info = (up.updater.remote_manifest or {}).get("releases", {}).get(res.target, {})
        if info.get("changes"):
            line(dim("    Değişiklikler:"))
            for ch in info["changes"]:
                line(dim(f"      • {ch}"))
        if res.mandatory:
            line(red("    Bu güncelleme ZORUNLUDUR; atlanması önerilmez."))
    line()
    return res


def action_apply(target: str | None = None) -> None:
    line()
    res = up.updater.check()
    if res.status == "error":
        line(red(f"  ✗ Kontrol başarısız: {res.message}"))
        return
    if res.status == "uptodate" and not target:
        line(green(f"  ✓ {res.message}"))
        return

    tgt = target or res.target
    if not tgt:
        line(yellow("  Uygulanacak sürüm yok."))
        return

    if res.mandatory:
        line(red(f"  ZORUNLU güncelleme uygulanıyor: {tgt}"))
        onay = "e"
    else:
        onay = input(f"  {green(tgt)} sürümü uygulanacak. Onaylıyor musunuz? [e/H] ").strip().lower()
    if onay not in ("e", "evet", "y", "yes"):
        line(dim("  İptal edildi."))
        return

    line(dim("  İndiriliyor ve uygulanıyor..."))
    result = up.updater.apply(tgt)
    rule()
    if result.ok:
        line(green(f"  ✓ {result.message}"))
        if result.backup:
            line(dim(f"    Yedek: {result.backup}"))
        for entry in result.log:
            line(dim(f"    → {entry}"))
        post = up.updater.config.get("update", {})
        if not post.get("restartAfterUpdate"):
            line(yellow("    Not: Değişikliklerin etkin olması için backend'i "
                        "yeniden başlatın (start.bat)."))
    else:
        line(red(f"  ✗ {result.message}"))
    line()


def action_settings() -> None:
    u = up.updater
    while True:
        banner()
        rule()
        line(bold("  AYARLAR"))
        rule()
        ch = u.channel
        beta = u.allow_beta
        auto = u.config.get("autoUpdate", {})
        upd = u.config.get("update", {})
        line(f"  {magenta('1')}  Kanal             : {cyan(ch)}")
        line(f"  {magenta('2')}  Beta indir        : "
             f"{(green('açık') if beta else red('kapalı'))}")
        line(f"  {magenta('3')}  Otomatik kontrol  : "
             f"{(green('açık') if auto.get('enabled') else red('kapalı'))}")
        line(f"  {magenta('4')}  Kontrol aralığı   : {cyan(str(auto.get('checkIntervalMinutes', 30)) + ' dk')}")
        line(f"  {magenta('5')}  Otomatik uygula   : "
             f"{('evet' if auto.get('applyAutomatically') else 'hayır')}")
        line(f"  {magenta('6')}  Günc. sonrası başlat: "
             f"{('evet' if upd.get('restartAfterUpdate') else 'hayır')}")
        line(f"  {magenta('7')}  Yedek al          : "
             f"{('evet' if upd.get('backup', True) else 'hayır')}")
        line(f"  {magenta('0')}  Geri")
        rule()
        sec = input(dim("  Seçim: ")).strip()
        if sec == "0":
            return
        elif sec == "1":
            newv = input("  Yeni kanal (stable/beta): ").strip().lower()
            if newv in ("stable", "beta", "kararlı", "kararli"):
                u.config["channels"]["current"] = "stable" if newv.startswith(("s", "k")) else "beta"
                u.save_config()
                line(green("  ✓ Kanal güncellendi."))
        elif sec == "2":
            u.config["channels"]["allowBeta"] = not beta
            u.save_config()
            line(green(f"  ✓ Beta indirme: "
                       f"{'açık' if u.config['channels']['allowBeta'] else 'kapalı'}"))
        elif sec == "3":
            auto["enabled"] = not auto.get("enabled", True)
            u.config["autoUpdate"] = auto
            u.save_config()
            line(green(f"  ✓ Otomatik kontrol: "
                       f"{'açık' if auto['enabled'] else 'kapalı'}"))
        elif sec == "4":
            val = input("  Dakika cinsinden aralık (örn. 30): ").strip()
            if val.isdigit() and int(val) > 0:
                auto["checkIntervalMinutes"] = int(val)
                u.config["autoUpdate"] = auto
                u.save_config()
                line(green(f"  ✓ Aralık: {val} dk"))
        elif sec == "5":
            auto["applyAutomatically"] = not auto.get("applyAutomatically", False)
            u.config["autoUpdate"] = auto
            u.save_config()
            line(green(f"  ✓ Otomatik uygula: "
                       f"{'evet' if auto['applyAutomatically'] else 'hayır'}"))
        elif sec == "6":
            upd["restartAfterUpdate"] = not upd.get("restartAfterUpdate", False)
            u.config["update"] = upd
            u.save_config()
            line(green(f"  ✓ Güncelleme sonrası başlat: "
                       f"{'evet' if upd['restartAfterUpdate'] else 'hayır'}"))
        elif sec == "7":
            upd["backup"] = not upd.get("backup", True)
            u.config["update"] = upd
            u.save_config()
            line(green(f"  ✓ Yedek al: {'evet' if upd['backup'] else 'hayır'}"))
        else:
            line(red("  Geçersiz seçim."))
        input(dim("  Devam için Enter..."))


def action_changelog() -> None:
    path = up.DEFAULT_MANIFEST.parent / "ChangeLog.md"
    clear()
    rule()
    line(bold("  SÜRÜM GEÇMİŞİ (ChangeLog)"))
    rule()
    if path.exists():
        try:
            line(path.read_text("utf-8"))
        except Exception as e:  # noqa: BLE001
            line(red(f"  Okunamadı: {e}"))
    else:
        # Yerel bildirimdeki changes listesinden özet çıkar
        try:
            import json
            data = json.loads(up.DEFAULT_MANIFEST.read_text("utf-8-sig"))
            norm = up.Updater._normalize_manifest(data)
            for ver in sorted(norm["releases"], key=up._version_key, reverse=True):
                info = norm["releases"][ver]
                line(bold(cyan(f"  {ver}  {info.get('title', '')}")))
                for ch in info.get("changes", []) or []:
                    line(f"    • {ch}")
                line()
        except Exception as e:  # noqa: BLE001
            line(yellow(f"  ChangeLog bulunamadı: {e}"))
    rule()
    input(dim("  Devam için Enter..."))


def action_status() -> None:
    u = up.updater
    clear()
    rule()
    line(bold("  DURUM"))
    rule()
    line(f"  Kurulu sürüm    : {green(u.current_version)}")
    line(f"  Kanal           : {cyan(u.channel)}")
    line(f"  Beta izni       : {'açık' if u.allow_beta else 'kapalı'}")
    last = u.config.get("lastCheck", 0)
    if last:
        import time as _t
        line(f"  Son kontrol     : {_t.strftime('%Y-%m-%d %H:%M:%S', _t.localtime(last / 1000))}")
    lr = u.config.get("lastResult") or {}
    if lr:
        line(f"  Son sonuç       : {lr.get('status')} — {lr.get('message')}")
    line(f"  Yerel ChangeLog : "
         f"{'var' if (up.DEFAULT_MANIFEST.parent / 'ChangeLog.md').exists() else 'yok'}")
    line(f"  Servis durumu   : "
         f"{green('çalışıyor') if up.update_service._thread and up.update_service._thread.is_alive() else dim('kapalı')}")
    line(f"  Günlük dosyası  : {up.LOG_FILE}")
    rule()
    input(dim("  Devam için Enter..."))


# ---------------------------------------------------------------------------
# Ana akış
# ---------------------------------------------------------------------------
def interactive() -> int:
    while True:
        banner()
        menu()
        sec = input(dim("  Seçim: ")).strip()
        if sec == "0":
            line(dim("  Görüşürüz."))
            return 0
        elif sec == "1":
            action_check()
            input(dim("  Devam için Enter..."))
        elif sec == "2":
            action_apply()
            input(dim("  Devam için Enter..."))
        elif sec == "3":
            action_settings()
        elif sec == "4":
            action_changelog()
        elif sec == "5":
            action_status()
        else:
            line(red("  Geçersiz seçim. 0-5 arası bir rakam girin."))
            input(dim("  Devam için Enter..."))


def headless(argv: list[str]) -> int:
    cmd = argv[0] if argv else "help"
    u = up.updater
    if cmd in ("check", "kontrol"):
        res = up.updater.check()
        print(res.message)
        return 0 if res.ok else 1
    if cmd in ("apply", "indir", "guncelle", "güncelle"):
        res = up.updater.check()
        target = argv[1] if len(argv) > 1 else res.target
        r = up.updater.apply(target)
        print(r.message)
        return 0 if r.ok else 1
    if cmd in ("status", "durum"):
        u = up.updater
        print(f"Kurulu: {u.current_version}  Kanal: {u.channel}  Beta: {u.allow_beta}")
        print(f"Sonuç: {u.config.get('lastResult')}")
        return 0
    if cmd == "beta":
        val = (argv[1] if len(argv) > 1 else "").lower()
        u.config["channels"]["allowBeta"] = val in ("on", "açık", "acik", "1", "true", "evet")
        u.save_config()
        print(f"Beta: {u.allow_beta}")
        return 0
    if cmd == "auto":
        val = (argv[1] if len(argv) > 1 else "").lower()
        u.config["autoUpdate"]["enabled"] = val in ("on", "açık", "acik", "1", "true", "evet")
        u.save_config()
        print(f"Otomatik: {u.config['autoUpdate']['enabled']}")
        return 0
    if cmd == "channel" or cmd == "kanal":
        val = (argv[1] if len(argv) > 1 else "stable").lower()
        u.config["channels"]["current"] = "beta" if val.startswith("b") else "stable"
        u.save_config()
        print(f"Kanal: {u.channel}")
        return 0
    print(__doc__)
    return 0


def main() -> int:
    try:
        argv = sys.argv[1:]
        if argv:
            return headless(argv)
        return interactive()
    except KeyboardInterrupt:
        print()
        line(dim("  İptal edildi."))
        return 130


if __name__ == "__main__":
    sys.exit(main())
