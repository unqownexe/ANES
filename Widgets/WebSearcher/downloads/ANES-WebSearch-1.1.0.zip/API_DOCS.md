# Gelişmiş Arama API'si — Dokümantasyon

Çoklu sağlayıcı destekli meta-arama servisi. Bir sağlayıcı çalışmazsa otomatik
olarak bir sonrakine geçer:

```
SearXNG  →  Purili  →  agent-webtool
```

- **Base URL:** `http://localhost:3000`
- **İçerik tipi:** `application/json`
- **Kimlik doğrulama:** Yok
- **CORS:** Tüm origin'lere açık (`Access-Control-Allow-Origin: *`)

---

## İçindekiler

1. [Çalıştırma](#çalıştırma)
2. [Ortam Değişkenleri](#ortam-değişkenleri)
3. [Endpoint Özeti](#endpoint-özeti)
4. [`GET /`](#get-)
5. [`GET /search`](#get-search)
6. [`GET /health`](#get-health)
7. [`GET /providers`](#get-providers)
8. [`GET /stats`](#get-stats)
9. [`DELETE /cache`](#delete-cache)
10. [Hata Yanıtları ve Kodları](#hata-yanıtları-ve-kodları)
11. [Sağlayıcı (Fallback) Mantığı](#sağlayıcı-fallback-mantığı)
12. [Önbellek Davranışı](#önbellek-davranışı)
13. [Hız Sınırlandırma (Rate Limiting)](#hız-sınırlandırma-rate-limiting)

---

## Çalıştırma

```bash
node index.js
```

Sunucu varsayılan olarak `http://localhost:3000` üzerinde ayağa kalkar.

---

## Ortam Değişkenleri

| Değişken | Varsayılan | Açıklama |
|----------|-----------:|----------|
| `PORT` | `3000` | HTTP sunucu portu. |
| `HOST` | `0.0.0.0` | Bağlanılacak ağ arayüzü. |
| `REQUEST_TIMEOUT_MS` | `15000` | Tek bir sağlayıcı için zaman aşımı (ms). |
| `CACHE_TTL_MS` | `60000` | Önbellek girdilerinin yaşam süresi (ms). |
| `CACHE_MAX_ENTRIES` | `200` | Önbellekteki maksimum girdi sayısı (FIFO). |
| `RATE_LIMIT_MAX` | `60` | IP başına 60 saniyede izin verilen istek sayısı. |

---

## Endpoint Özeti

| Metod | Yol | Açıklama |
|-------|-----|----------|
| `GET` | `/` | Servis bilgisi ve endpoint listesi |
| `GET` | `/search` | Arama yapar (ana endpoint) |
| `GET` | `/health` | Sağlık durumu |
| `GET` | `/providers` | Sağlayıcı durumu ve kullanımı |
| `GET` | `/stats` | Kullanım istatistikleri |
| `DELETE` | `/cache` | Önbelleği temizler |

---

## `GET /`

Servis kök bilgisi ve mevcut endpointlerin listesini döndürür.

**İstek:**

```http
GET http://localhost:3000/
```

**Örnek Yanıt (200):**

```json
{
  "name": "Gelişmiş Arama API",
  "version": "2.0.0",
  "status": "çalışıyor",
  "uptime": "3dk 12sn",
  "documentation": "API_DOCS.md",
  "endpoints": [
    { "method": "GET", "path": "/", "description": "Servis bilgisi (bu endpoint)" },
    {
      "method": "GET",
      "path": "/search",
      "description": "Arama yapar",
      "query": ["q", "limit", "page", "language", "categories", "engines", "timeRange", "safeSearch", "provider", "noCache"]
    },
    { "method": "GET", "path": "/health", "description": "Sağlık durumu" },
    { "method": "GET", "path": "/providers", "description": "Sağlayıcı durumu ve kullanımı" },
    { "method": "GET", "path": "/stats", "description": "Kullanım istatistikleri" },
    { "method": "DELETE", "path": "/cache", "description": "Önbelleği temizler" }
  ]
}
```

---

## `GET /search`

Ana arama endpointi. Arama sorgusunu sırayla aktif sağlayıcılara gönderir ve
ilk başarılı sonucu döndürür.

### Query Parametreleri

| Parametre | Tip | Zorunlu | Varsayılan | Açıklama |
|-----------|-----|:------:|-----------:|----------|
| `q` | string | ✅ | — | Arama sorgusu. |
| `limit` | integer | ❌ | `10` | Döndürülecek maksimum sonuç sayısı. `1`–`50` arası. |
| `page` | integer | ❌ | `1` | Sayfa numarası. `1`–`10` arası (SearXNG `pageno`'ya eşlenir). |
| `language` | string | ❌ | — | Dil kodu, ör. `tr`, `en`. |
| `categories` | string | ❌ | — | Virgülle ayrılmış kategori listesi, ör. `general,news`. |
| `engines` | string | ❌ | — | Virgülle ayrılmış motor listesi, ör. `google,bing`. |
| `timeRange` | string | ❌ | — | Zaman aralığı: `day`, `week`, `month`, `year`. |
| `safeSearch` | boolean | ❌ | — | `true`/`false` güvenli arama filtresi. |
| `provider` | string | ❌ | — | Belirli bir sağlayıcıyı zorlar: `searxng`, `purili`, `agent-webtool`. |
| `noCache` | boolean | ❌ | `false` | `true` ise önbellek atlanır ve sonuç önbelleğe yazılmaz. |

> **Not:** `provider` belirtilirse önbellek kullanılmaz (zorlanan sağlayıcı her
> zaman canlı çağrılır). `language`, `categories`, `engines`, `timeRange` ve
> `safeSearch` yalnızca **SearXNG** sağlayıcısı tarafından dikkate alınır;
> Purili ve agent-webtool yalnızca sorgu metnini kullanır.

### Örnek İstekler

```http
# Basit arama
GET http://localhost:3000/search?q=node.js

# Limit ve sayfa ile
GET http://localhost:3000/search?q=express%20tutorial&limit=5&page=2

# Dil ve zaman aralığı ile
GET http://localhost:3000/search?q=haberler&language=tr&timeRange=day

# Sağlayıcıyı zorla (SearXNG'yi atla)
GET http://localhost:3000/search?q=test&provider=purili

# Önbelleği atla
GET http://localhost:3000/search?q=test&noCache=true
```

### Örnek Yanıt — Başarılı (200)

```json
{
  "query": "node.js",
  "options": {
    "limit": 10,
    "page": 1,
    "language": null,
    "categories": null,
    "engines": null,
    "timeRange": null,
    "safeSearch": null
  },
  "cached": false,
  "source": "searxng",
  "fallbackChain": ["searxng"],
  "tookMs": 842,
  "count": 2,
  "results": [
    {
      "title": "Node.js — JavaScript çalışma zamanı",
      "url": "https://nodejs.org/",
      "snippet": "Node.js, Chrome V8 motoru üzerine kurulu bir JavaScript çalışma zamanıdır.",
      "engine": "google",
      "category": "general",
      "score": 1.0
    },
    {
      "title": "Node.js nedir? — Başlangıç rehberi",
      "url": "https://example.com/nodejs-nedir",
      "snippet": "Bu yazıda Node.js'in ne olduğunu ve nasıl kullanıldığını öğreneceksiniz.",
      "engine": "bing",
      "category": "general",
      "score": 0.87
    }
  ],
  "meta": {
    "numberOfResults": 1200000,
    "query": "node.js",
    "engines": ["google", "bing"]
  }
}
```

### Örnek Yanıt — Önbellekten (200)

Aynı sorgu `CACHE_TTL_MS` süresi içinde tekrarlandığında `cached: true` döner:

```json
{
  "query": "node.js",
  "cached": true,
  "source": "searxng",
  "count": 2,
  "results": [
    { "title": "Node.js — JavaScript çalışma zamanı", "url": "https://nodejs.org/", "snippet": "..." }
  ]
}
```

### Örnek Yanıt — Fallback Kullanıldığında (200)

SearXNG çöktüğünde Purili'ye geçilirse `source` ve `fallbackChain` ile birlikte
atlanan sağlayıcılar `warnings` içinde raporlanır:

```json
{
  "query": "test",
  "cached": false,
  "source": "purili",
  "fallbackChain": ["purili"],
  "tookMs": 1523,
  "count": 3,
  "results": [
    { "title": "Test sonucu 1", "url": "https://example.com/1", "snippet": "..." }
  ],
  "meta": {},
  "warnings": [
    { "provider": "searxng", "error": "Sağlayıcı hazır değil (atlandı)" }
  ]
}
```

### Örnek Yanıt — `q` Eksik (400)

```json
{
  "error": "Arama yapmak için 'q' query parametresi zorunludur.",
  "example": "/search?q=node.js&limit=5"
}
```

### Örnek Yanıt — Tüm Sağlayıcılar Başarısız (502)

```json
{
  "error": "Tüm arama sağlayıcıları başarısız oldu.",
  "details": [
    { "provider": "searxng", "error": "Sağlayıcı hazır değil (atlandı)" },
    { "provider": "purili", "error": "modül bulunamadı" },
    { "provider": "agent-webtool", "error": "spawn webtool ENOENT" }
  ]
}
```

---

## `GET /health`

Uygulamanın ve sağlayıcıların sağlık durumunu döndürür.

**İstek:**

```http
GET http://localhost:3000/health
```

**Örnek Yanıt (200):**

```json
{
  "status": "ok",
  "uptime": "12dk 5sn",
  "uptimeMs": 725000,
  "timestamp": "2026-11-13T18:04:31.673Z",
  "memory": {
    "rss": "78.4 MB",
    "heapUsed": "21.2 MB"
  },
  "host": "DESKTOP-ABC",
  "readyProviders": ["searxng", "purili"],
  "providers": {
    "searxng": { "ready": true, "note": "hazır" },
    "purili": { "ready": true, "note": "modül yüklü" },
    "agent-webtool": { "ready": false, "note": "CLI bulunamadı ('npm install -g agent-webtool')" }
  }
}
```

`note` alanı sağlayıcının neden hazır olmadığını (varsa hata mesajını) açıklar.

---

## `GET /providers`

Sağlayıcıları, durumlarını ve o ana kadarki kullanım sayılarını döndürür.

**İstek:**

```http
GET http://localhost:3000/providers
```

**Örnek Yanıt (200):**

```json
{
  "order": ["searxng", "purili", "agent-webtool"],
  "providers": [
    { "name": "searxng", "status": { "ready": true, "note": "hazır" }, "usage": 42 },
    { "name": "purili", "status": { "ready": true, "note": "modül yüklü" }, "usage": 3 },
    { "name": "agent-webtool", "status": { "ready": false, "note": "CLI bulunamadı" }, "usage": 0 }
  ]
}
```

`order` dizisi, arama sırasında denenen **fallback sırasını** gösterir.

---

## `GET /stats`

Toplam istek, önbellek ve sağlayıcı kullanım istatistiklerini döndürür.

**İstek:**

```http
GET http://localhost:3000/stats
```

**Örnek Yanıt (200):**

```json
{
  "uptime": "45dk 2sn",
  "startedAt": "2026-11-13T17:19:29.000Z",
  "requests": {
    "total": 128,
    "successful": 120,
    "failed": 8
  },
  "cache": {
    "entries": 34,
    "maxEntries": 200,
    "ttlMs": 60000,
    "hits": 51,
    "misses": 77,
    "hitRate": "39.8%"
  },
  "providerUsage": {
    "searxng": 110,
    "purili": 10
  }
}
```

---

## `DELETE /cache`

Bellek içi önbelleği tamamen temizler.

**İstek:**

```http
DELETE http://localhost:3000/cache
```

**Örnek Yanıt (200):**

```json
{
  "message": "Önbellek temizlendi.",
  "clearedEntries": 34
}
```

---

## Hata Yanıtları ve Kodları

Tüm hatalar şu biçimde JSON döner:

```json
{ "error": "Açıklama", "details": "opsiyonel ek detay" }
```

| Kod | Anlam | Ne Zaman |
|-----|-------|----------|
| `200` | Başarılı | İstek başarıyla yanıtlandı. |
| `400` | Hatalı İstek | `q` eksik veya geçersiz `provider` değeri. |
| `404` | Bulunamadı | Var olmayan bir endpoint çağrıldı. |
| `429` | Çok Fazla İstek | Hız limiti aşıldı (`Retry-After` başlığına bakın). |
| `500` | Sunucu Hatası | Beklenmeyen bir hata oluştu. |
| `502` | Kötü Ağ Geçidi | Tüm arama sağlayıcıları başarısız oldu. |

**Geçersiz sağlayıcı örneği (400):**

```json
{ "error": "Bilinmeyen sağlayıcı: 'google-xyz'" }
```

**Bilinmeyen endpoint örneği (404):**

```json
{
  "error": "Endpoint bulunamadı.",
  "path": "/searchX",
  "hint": "Mevcut endpointler için kök dizini (/) ziyaret edin."
}
```

---

## Sağlayıcı (Fallback) Mantığı

Aramalar şu sırayla denenir; biri başarısız olursa bir sonrakine geçilir:

1. **SearXNG** — Yerel SearXNG sunucusu. `language`, `categories`, `engines`,
   `timeRange`, `safeSearch` ve `page` parametrelerini destekler.
2. **Purili** — `@purili/web-search` modülü. Yalnızca sorgu metnini kullanır.
3. **agent-webtool** — Global `webtool` CLI'ı (`npm install -g agent-webtool`).
   Çıktı markdown biçiminde olup tek bir ham sonuç olarak döner
   (`"raw": true`).

Her sağlayıcı `REQUEST_TIMEOUT_MS` süresi kadar beklenir; aşılırsa atlanır.
Başarılı sağlayıcı `source` alanında, başarısız olanlar `warnings` içinde
raporlanır. `?provider=...` ile tek bir sağlayıcı zorlanabilir.

---

## Önbellek Davranışı

- Önbellek anahtarı, sorgunun **ve tüm arama seçeneklerinin** (limit, page,
  language, categories, engines, timeRange, safeSearch) birleşimidir.
- Girdiler `CACHE_TTL_MS` (varsayılan 60 sn) boyunca geçerlidir.
- Kapasite (`CACHE_MAX_ENTRIES`, varsayılan 200) dolduğunda en eski girdi
  (FIFO) çıkarılır.
- `?noCache=true` ile önbellek okuma **ve** yazma atlanır.
- `?provider=...` kullanıldığında önbellek devre dışı kalır.
- Önbellekten dönen yanıtlarda `cached: true` alanı bulunur.

---

## Hız Sınırlandırma (Rate Limiting)

- Yalnızca `GET /search` endpointine uygulanır.
- IP başına `RATE_LIMIT_MAX` (varsayılan 60) istek / 60 saniye.
- Her yanıtta şu başlıklar döner:

| Başlık | Açıklama |
|--------|----------|
| `X-RateLimit-Limit` | Pencere başına izin verilen toplam istek. |
| `X-RateLimit-Remaining` | Kalan istek hakkı. |
| `X-RateLimit-Reset` | Pencerenin sıfırlanmasına kalan saniye. |
| `Retry-After` | (Yalnızca 429'da) Kaç saniye sonra tekrar denenebileceği. |
| `X-Response-Time` | İsteğin işlenme süresi (ör. `842.3ms`). |

**Limit aşıldığında (429):**

```json
{
  "error": "Çok fazla istek gönderildi. Lütfen daha sonra tekrar deneyin.",
  "retryAfterSeconds": 27
}
```
