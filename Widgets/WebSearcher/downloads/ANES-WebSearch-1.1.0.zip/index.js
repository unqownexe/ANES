/**
 * ============================================================================
 *  Gelişmiş Arama API'si (Advanced Search API)
 * ============================================================================
 *  Çoklu sağlayıcı destekli (SearXNG --> Purili --> agent-webtool) meta-arama
 *  servisi. Sağlayıcılardan biri çalışmazsa otomatik olarak bir sonrakine
 *  (fallback) geçer.
 *
 *  Özellikler:
 *   - Sağlayıcı soyutlaması + otomatik yedekleme zinciri (fallback chain)
 *   - Basit TTL tabanlı bellek içi (in-memory) önbellek
 *   - IP başına istek hızı sınırlandırma (rate limiting)
 *   - İstek süresi ölçümü ve loglama middleware'i
 *   - CORS desteği
 *   - Sağlayıcı zaman aşımı (timeout) koruması
 *   - Sağlık (health), istatistik (stats) ve sağlayıcı (providers) endpointleri
 *   - Graceful shutdown
 *
 *  Detaylı endpoint dokümantasyonu için: API_DOCS.md
 *  Çalıştırma:  node index.js
 * ============================================================================
 */

'use strict';

const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { execFile } = require('child_process');
const { promisify } = require('util');

const execFileAsync = promisify(execFile);

// ---------------------------------------------------------------------------
// Yapılandırma (ortam değişkenleriyle geçersiz kılınabilir)
// ---------------------------------------------------------------------------
const CONFIG = {
    port: parseInt(process.env.PORT, 10) || 3000,
    host: process.env.HOST || '0.0.0.0',
    requestTimeoutMs: parseInt(process.env.REQUEST_TIMEOUT_MS, 10) || 15000,
    defaultLimit: 10,
    maxLimit: 50,
    cacheTtlMs: parseInt(process.env.CACHE_TTL_MS, 10) || 60000,
    cacheMaxEntries: parseInt(process.env.CACHE_MAX_ENTRIES, 10) || 200,
    rateLimit: {
        windowMs: 60000,
        maxRequests: parseInt(process.env.RATE_LIMIT_MAX, 10) || 60
    },
    // Güncelleme kontrolü ayarları (ortam değişkenleriyle geçersiz kılınabilir).
    update: {
        // Kontrol tamamen kapatılabilir: UPDATE_CHECK_ENABLED=false
        enabled: process.env.UPDATE_CHECK_ENABLED !== 'false',
        // Uzak sürüm bilgisinin (version.json) bulunduğu adres.
        versionUrl:
            process.env.UPDATE_VERSION_URL ||
            'https://raw.githubusercontent.com/unqownexe/ANES/refs/heads/main/Widgets/WebSearcher/updates/version.json',
        // Kontrol aralığı: varsayılan 30 dakika.
        intervalMs: parseInt(process.env.UPDATE_CHECK_INTERVAL_MS, 10) || 30 * 60 * 1000,
        // Tek bir HTTP isteği için zaman aşımı.
        timeoutMs: parseInt(process.env.UPDATE_TIMEOUT_MS, 10) || 10000,
        // Yeni sürüm bulunduğunda arşivi otomatik indir.
        autoDownload: parseBool(process.env.UPDATE_AUTO_DOWNLOAD)
    }
};

const START_TIME = Date.now();

// ---------------------------------------------------------------------------
// Uygulama durumu
// ---------------------------------------------------------------------------
const app = express();

/** SearXNG istemcisi (başlatıldığında atanır). */
let searxngClient = null;

/** Sağlayıcıların anlık durumu (health endpointi bunu raporlar). */
const providersStatus = {
    searxng: { ready: false, note: 'başlatılıyor...' },
    purili: { ready: null, note: 'yüklendiğinde belirlenir' },
    'agent-webtool': { ready: null, note: 'çalıştırıldığında belirlenir' }
};

/** Kullanım istatistikleri. */
const stats = {
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    cacheHits: 0,
    cacheMisses: 0,
    providerUsage: {},
    startedAt: new Date(START_TIME).toISOString()
};

// ---------------------------------------------------------------------------
// Yardımcı (helper) fonksiyonlar
// ---------------------------------------------------------------------------

/**
 * Virgülle ayrılmış bir string'i temizlenmiş bir diziye çevirir.
 * Örnek: "google,bing" -> ["google", "bing"]
 */
function parseList(value) {
    if (!value) return null;
    const list = String(value)
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean);
    return list.length ? list : null;
}

/** "true"/"1"/"yes" gibi değerleri boolean'a çevirir. */
function parseBool(value) {
    return ['true', '1', 'yes', 'on'].includes(String(value).toLowerCase());
}

/**
 * Bir query değerini tam sayıya çevirir ve [min, max] aralığına sıkıştırır.
 * Geçersizse fallback döner.
 */
function parseIntInRange(value, min, max, fallback) {
    const n = parseInt(value, 10);
    if (Number.isNaN(n)) return fallback;
    return Math.min(Math.max(n, min), max);
}

/** İnsan-okunur süre metni üretir (ör. "1h 20m"). */
function formatUptime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const parts = [];
    if (days) parts.push(`${days}g`);
    if (hours) parts.push(`${hours}s`);
    if (minutes) parts.push(`${minutes}dk`);
    parts.push(`${seconds}sn`);
    return parts.join(' ');
}

/**
 * Bir promise'e zaman aşımı ekler. Süre aşılırsa reddeder.
 */
function withTimeout(promise, ms, label) {
    let timer;
    const timeout = new Promise((_, reject) => {
        timer = setTimeout(
            () => reject(new Error(`'${label}' sağlayıcısı ${ms}ms içinde yanıt vermedi (timeout).`)),
            ms
        );
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

// ---------------------------------------------------------------------------
// Basit TTL tabanlı bellek içi önbellek
// ---------------------------------------------------------------------------
const cache = new Map();

/** Önbellek anahtarı üretir (arama parametrelerinin tamamını kapsar). */
function buildCacheKey(query, options) {
    return JSON.stringify({
        q: query,
        limit: options.limit,
        page: options.page,
        language: options.language,
        categories: options.categories,
        engines: options.engines,
        timeRange: options.timeRange,
        safeSearch: options.safeSearch
    });
}

function cacheGet(key) {
    const entry = cache.get(key);
    if (!entry) {
        stats.cacheMisses++;
        return null;
    }
    if (Date.now() > entry.expiresAt) {
        cache.delete(key);
        stats.cacheMisses++;
        return null;
    }
    stats.cacheHits++;
    return entry.value;
}

function cacheSet(key, value) {
    // Kapasite dolduysa en eski girdiyi (FIFO) çıkar.
    if (cache.size >= CONFIG.cacheMaxEntries) {
        const oldestKey = cache.keys().next().value;
        if (oldestKey !== undefined) cache.delete(oldestKey);
    }
    cache.set(key, { value, expiresAt: Date.now() + CONFIG.cacheTtlMs });
}

function cacheClear() {
    const size = cache.size;
    cache.clear();
    return size;
}

// ---------------------------------------------------------------------------
// IP başına basit hız sınırlandırma (rate limiting)
// ---------------------------------------------------------------------------
const rateBuckets = new Map();

function rateLimiter(req, res, next) {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();

    let bucket = rateBuckets.get(ip);
    if (!bucket || now > bucket.resetAt) {
        bucket = { count: 0, resetAt: now + CONFIG.rateLimit.windowMs };
        rateBuckets.set(ip, bucket);
    }
    bucket.count++;

    const remaining = Math.max(0, CONFIG.rateLimit.maxRequests - bucket.count);
    const retryAfter = Math.ceil((bucket.resetAt - now) / 1000);

    res.setHeader('X-RateLimit-Limit', CONFIG.rateLimit.maxRequests);
    res.setHeader('X-RateLimit-Remaining', remaining);
    res.setHeader('X-RateLimit-Reset', retryAfter);

    if (bucket.count > CONFIG.rateLimit.maxRequests) {
        res.setHeader('Retry-After', retryAfter);
        return res.status(429).json({
            error: 'Çok fazla istek gönderildi. Lütfen daha sonra tekrar deneyin.',
            retryAfterSeconds: retryAfter
        });
    }
    next();
}

// ---------------------------------------------------------------------------
// Genel middleware'ler
// ---------------------------------------------------------------------------

// İstek süresi ölçümü + loglama
app.use((req, res, next) => {
    const start = process.hrtime.bigint();

    // X-Response-Time başlığı, yanıt başlıkları gönderilmeden ÖNCE eklenmelidir.
    // (finish olayında setHeader çağrılırsa ERR_HTTP_HEADERS_SENT hatası oluşur.)
    const originalWriteHead = res.writeHead;
    res.writeHead = function (...args) {
        const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
        res.setHeader('X-Response-Time', `${durationMs.toFixed(1)}ms`);
        return originalWriteHead.apply(this, args);
    };

    res.on('finish', () => {
        const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
        console.log(
            `[${new Date().toISOString()}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${durationMs.toFixed(1)}ms)`
        );
    });
    next();
});

// CORS
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
});

app.use(express.json());

// ---------------------------------------------------------------------------
// Sağlayıcılar (provider) soyutlaması
// ---------------------------------------------------------------------------
/**
 * Her sağlayıcı şu sözleşmeye uyar:
 *   {
 *     name: string,
 *     isReady?: () => boolean,                 // opsiyonel hazırlık kontrolü
 *     search: (query, options) => Promise<{ results, meta }>
 *   }
 * Sonuç elemanlarının ortak biçimi: { title, url, snippet, ... }
 */
const providers = [
    {
        name: 'searxng',
        isReady: () => Boolean(searxngClient),
        search: async (query, options) => {
            const params = { q: query };
            if (options.language) params.language = options.language;
            if (options.categories) params.categories = options.categories;
            if (options.engines) params.engines = options.engines;
            if (options.timeRange) params.time_range = options.timeRange;
            if (options.safeSearch !== undefined) params.safesearch = options.safeSearch;
            if (options.page && options.page > 1) params.pageno = options.page;

            const response = await searxngClient.search(params);
            const results = (response.results || []).map((r) => ({
                title: r.title,
                url: r.url,
                snippet: r.content,
                engine: r.engine,
                category: r.category,
                score: r.score
            }));
            return {
                results,
                meta: {
                    numberOfResults: response.number_of_results,
                    query: response.query,
                    engines: response.engines
                }
            };
        }
    },
    {
        name: 'purili',
        isReady: () => providersStatus.purili.ready,
        search: async (query) => {
            const { purili } = await import('@purili/web-search');
            const response = await purili.search(query);
            const results = (response.results || []).map((r) => ({
                title: r.title,
                url: r.url,
                snippet: r.snippet
            }));
            return { results, meta: {} };
        }
    },
    {
        name: 'agent-webtool',
        search: async (query, options) => {
            const { stdout } = await execFileAsync('webtool', [
                'search',
                query,
                '--limit',
                String(options.limit)
            ]);
            // CLI çıktısı markdown biçimindedir; tek bir ham sonuç olarak sarılır.
            return {
                results: [
                    {
                        title: `agent-webtool sonuçları: ${query}`,
                        url: null,
                        snippet: stdout.trim(),
                        raw: true
                    }
                ],
                meta: { format: 'markdown' }
            };
        }
    }
];

function getProvider(name) {
    return providers.find((p) => p.name === name) || null;
}

function trackProviderUsage(name) {
    stats.providerUsage[name] = (stats.providerUsage[name] || 0) + 1;
}

/**
 * Verilen sorguyu sağlayıcı zinciriyle arar. İlk başarılı sağlayıcının sonucunu
 * döner; tümü başarısız olursa hata fırlatır.
 */
async function performSearch(query, options, preferredProvider) {
    const chain = preferredProvider
        ? providers.filter((p) => p.name === preferredProvider)
        : providers;

    if (preferredProvider && chain.length === 0) {
        const err = new Error(`Bilinmeyen sağlayıcı: '${preferredProvider}'`);
        err.statusCode = 400;
        throw err;
    }

    const attempted = [];
    const errors = [];

    for (const provider of chain) {
        if (typeof provider.isReady === 'function' && !provider.isReady()) {
            errors.push({ provider: provider.name, error: 'Sağlayıcı hazır değil (atlandı)' });
            continue;
        }

        try {
            const startedAt = Date.now();
            const { results, meta } = await withTimeout(
                provider.search(query, options),
                CONFIG.requestTimeoutMs,
                provider.name
            );

            const limited = (results || []).slice(0, options.limit);
            attempted.push(provider.name);
            trackProviderUsage(provider.name);
            stats.successfulRequests++;

            return {
                source: provider.name,
                fallbackChain: attempted,
                tookMs: Date.now() - startedAt,
                count: limited.length,
                results: limited,
                meta: meta || {},
                ...(errors.length ? { warnings: errors } : {})
            };
        } catch (error) {
            errors.push({ provider: provider.name, error: error.message });
            console.warn(`[provider:${provider.name}] başarısız: ${error.message}`);
        }
    }

    stats.failedRequests++;
    const finalError = new Error('Tüm arama sağlayıcıları başarısız oldu.');
    finalError.statusCode = 502;
    finalError.details = errors;
    throw finalError;
}

// ---------------------------------------------------------------------------
// Başlangıç: sağlayıcı hazırlık kontrolleri
// ---------------------------------------------------------------------------
async function initializeSearch() {
    // 1) SearXNG sunucusunu başlatmayı dene.
    try {
        const { startServer } = require('@searxng-js/searxng');
        const server = await startServer();
        searxngClient = server.client;
        providersStatus.searxng = { ready: true, note: 'hazır' };
        console.log('✅ SearXNG sunucusu hazır.');
    } catch (error) {
        providersStatus.searxng = { ready: false, note: error.message };
        console.error('❌ SearXNG başlatılamadı, yedek sağlayıcılar kullanılacak:', error.message);
    }

    // 2) Purili modülü yüklenebiliyor mu?
    //    NOT: @purili/web-search ESM-only bir pakettir ve package.json'ında
    //    yalnızca "import" koşulu tanımlıdır. Bu yüzden CommonJS'deki
    //    require.resolve() ERR_PACKAGE_PATH_NOT_EXPORTED verir; doğru kontrol
    //    dinamik import() ile yapılır.
    try {
        await import('@purili/web-search');
        providersStatus.purili = { ready: true, note: 'modül yüklü (ESM)' };
    } catch (error) {
        providersStatus.purili = { ready: false, note: error.message };
    }

    // 3) agent-webtool CLI erişilebilir mi?
    try {
        await execFileAsync('webtool', ['--version']);
        providersStatus['agent-webtool'] = { ready: true, note: 'CLI erişilebilir' };
    } catch {
        providersStatus['agent-webtool'] = {
            ready: false,
            note: "CLI bulunamadı ('npm install -g agent-webtool')"
        };
    }
}

/** Query parametrelerinden normalize edilmiş arama seçenekleri üretir. */
function parseSearchOptions(query) {
    return {
        limit: parseIntInRange(query.limit, 1, CONFIG.maxLimit, CONFIG.defaultLimit),
        page: parseIntInRange(query.page, 1, 10, 1),
        language: query.language || null,
        categories: parseList(query.categories),
        engines: parseList(query.engines),
        timeRange: query.timeRange || null,
        safeSearch: query.safeSearch !== undefined ? parseBool(query.safeSearch) : undefined
    };
}

// ---------------------------------------------------------------------------
// Güncelleme kontrolü (Update checker)
// ---------------------------------------------------------------------------
/** Bu uygulamanın yerel package.json bilgisi (sürüm kaynağı). */
function readLocalPackage() {
    try {
        return JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
    } catch (error) {
        console.warn(`[update] package.json okunamadı: ${error.message}`);
        return { version: '0.0.0' };
    }
}

/** "x.y.z" biçimindeki sürümü ayrıştırır. Geçersizse null döner. */
function parseVersion(version) {
    const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(version || '').trim());
    if (!m) return null;
    return { major: parseInt(m[1], 10), minor: parseInt(m[2], 10), patch: parseInt(m[3], 10) };
}

/** İki sürümü karşılaştırır. a > b ise pozitif, a < b ise negatif döner. */
function compareVersions(a, b) {
    const pa = parseVersion(a);
    const pb = parseVersion(b);
    if (!pa || !pb) return 0;
    if (pa.major !== pb.major) return pa.major - pb.major;
    if (pa.minor !== pb.minor) return pa.minor - pb.minor;
    return pa.patch - pb.patch;
}

/** VersionDetails içindeki en yüksek sürüm anahtarını bulur. */
function latestFromDetails(details) {
    if (!details || typeof details !== 'object') return null;
    const versions = Object.keys(details);
    if (!versions.length) return null;
    versions.sort((a, b) => compareVersions(b, a));
    return versions[0];
}

/** Yerel package.json (sürüm kaynağı). */
const localPackage = readLocalPackage();

/** Güncelleme durumu (health ve /update endpointleri bunu raporlar). */
const updateState = {
    enabled: CONFIG.update.enabled,
    localVersion: localPackage.version || '0.0.0',
    latestVersion: null,
    updateAvailable: false,
    mandatory: false,
    lastCheck: null,
    lastCheckError: null,
    nextCheck: null,
    checkCount: 0,
    downloadedPath: null,
    lastRemote: null
};

/** Periyodik kontrolün zamanlayıcı referansı. */
let updateTimer = null;

/** Verilen URL'den JSON indirir (yönlendirmeleri takip eder). */
function httpGetJson(url, timeoutMs) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(
            url,
            { timeout: timeoutMs, headers: { 'User-Agent': 'ANES-WebSearcher-UpdateChecker' } },
            (res) => {
                if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                    res.resume();
                    const nextUrl = new URL(res.headers.location, url).toString();
                    return resolve(httpGetJson(nextUrl, timeoutMs));
                }
                if (res.statusCode !== 200) {
                    res.resume();
                    return reject(new Error(`Beklenmeyen HTTP durumu: ${res.statusCode}`));
                }
                let data = '';
                res.setEncoding('utf8');
                res.on('data', (chunk) => { data += chunk; });
                res.on('end', () => {
                    try {
                        resolve(JSON.parse(data));
                    } catch (error) {
                        reject(new Error(`Geçersiz JSON yanıtı: ${error.message}`));
                    }
                });
            }
        );
        req.on('timeout', () => req.destroy(new Error(`İstek zaman aşımına uğradı (${timeoutMs}ms).`)));
        req.on('error', reject);
    });
}

/** Verilen URL'deki dosyayı diske indirir (yönlendirmeleri takip eder). */
function httpDownload(url, destPath, timeoutMs) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(
            url,
            { timeout: timeoutMs, headers: { 'User-Agent': 'ANES-WebSearcher-UpdateChecker' } },
            (res) => {
                if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                    res.resume();
                    const nextUrl = new URL(res.headers.location, url).toString();
                    return resolve(httpDownload(nextUrl, destPath, timeoutMs));
                }
                if (res.statusCode !== 200) {
                    res.resume();
                    return reject(new Error(`Beklenmeyen HTTP durumu: ${res.statusCode}`));
                }
                fs.mkdirSync(path.dirname(destPath), { recursive: true });
                const fileStream = fs.createWriteStream(destPath);
                res.pipe(fileStream);
                fileStream.on('finish', () => fileStream.close(() => resolve(destPath)));
                fileStream.on('error', reject);
            }
        );
        req.on('timeout', () => req.destroy(new Error(`İndirme zaman aşımına uğradı (${timeoutMs}ms).`)));
        req.on('error', reject);
    });
}

/** Yeni sürümün arşivini diske indirir. */
async function downloadUpdate(link, version) {
    const clean = String(link).trim();
    let fileName = `ANES-WebSearch-${version}.zip`;
    try {
        const base = path.basename(new URL(clean).pathname);
        if (base) fileName = base;
    } catch { /* varsayılan adı kullan */ }

    const destPath = path.join(__dirname, 'update-cache', fileName);
    console.log(`⬇️  Güncelleme indiriliyor: ${fileName}`);
    await httpDownload(clean, destPath, Math.max(CONFIG.update.timeoutMs, 60000));
    updateState.downloadedPath = destPath;
    console.log(`✅ Güncelleme indirildi: ${destPath}`);
    return destPath;
}

/**
 * Güncelleme olup olmadığını kontrol eder. Açılışta ve periyodik olarak çağrılır.
 * Hiçbir zaman fırlatmaz; hataları durum içinde raporlar.
 */
async function checkForUpdates(reason = 'manuel') {
    if (!CONFIG.update.enabled) return updateState;

    updateState.checkCount++;
    try {
        const remote = await httpGetJson(CONFIG.update.versionUrl, CONFIG.update.timeoutMs);
        const latest = remote.lastVersion || latestFromDetails(remote.VersionDetails);
        const detail =
            remote.VersionDetails && latest ? remote.VersionDetails[latest] : null;

        updateState.lastRemote = remote;
        updateState.latestVersion = latest || null;
        updateState.lastCheck = new Date().toISOString();
        updateState.lastCheckError = null;

        const available = Boolean(latest) && compareVersions(latest, updateState.localVersion) > 0;
        const wasAvailable = updateState.updateAvailable;
        updateState.updateAvailable = available;
        updateState.mandatory = Boolean(detail && detail.mandatory);

        if (available) {
            console.log(
                `⬆️  Yeni sürüm mevcut: ${updateState.localVersion} → ${latest}` +
                (updateState.mandatory ? ' (ZORUNLU)' : '')
            );
            // Yeni bulunduğunda (veya manuel istendiğinde) otomatik indir.
            if (detail && detail.downloadLink && (CONFIG.update.autoDownload || reason === 'manuel')) {
                if (!updateState.downloadedPath || reason === 'manuel') {
                    downloadUpdate(detail.downloadLink, latest).catch((error) =>
                        console.warn(`[update] Arşiv indirilemedi: ${error.message}`)
                    );
                }
            }
        } else if (!wasAvailable) {
            console.log(`[update] Güncel (yerel: ${updateState.localVersion}, uzak: ${latest || 'bilinmiyor'}) [${reason}]`);
        }
        return updateState;
    } catch (error) {
        updateState.lastCheck = new Date().toISOString();
        updateState.lastCheckError = error.message;
        console.warn(`[update] Kontrol başarısız (${reason}): ${error.message}`);
        return updateState;
    } finally {
        updateState.nextCheck = new Date(Date.now() + CONFIG.update.intervalMs).toISOString();
    }
}

/** Açılışta hemen bir kontrol yapar ve 30 dakikalık periyodik kontrolü başlatır. */
function scheduleUpdateChecks() {
    if (!CONFIG.update.enabled) {
        console.log('ℹ️  Güncelleme kontrolü devre dışı (UPDATE_CHECK_ENABLED=false).');
        return;
    }

    // 1) Açılışta hemen kontrol et.
    checkForUpdates('başlangıç');

    // 2) Periyodik kontrol (varsayılan 30 dakika).
    updateTimer = setInterval(() => checkForUpdates('periyodik'), CONFIG.update.intervalMs);
    if (typeof updateTimer.unref === 'function') updateTimer.unref();
    updateState.nextCheck = new Date(Date.now() + CONFIG.update.intervalMs).toISOString();

    const minutes = Math.round(CONFIG.update.intervalMs / 60000);
    console.log(`🔄 Güncelleme kontrolü aktif → açılışta ve her ${minutes} dakikada bir.`);
}

/** /update ve /health için özet rapor üretir. */
function buildUpdateReport() {
    const remote = updateState.lastRemote;
    const detail =
        remote && remote.VersionDetails && updateState.latestVersion
            ? remote.VersionDetails[updateState.latestVersion]
            : null;

    return {
        enabled: updateState.enabled,
        localVersion: updateState.localVersion,
        latestVersion: updateState.latestVersion,
        updateAvailable: updateState.updateAvailable,
        checkIntervalMinutes: CONFIG.update.intervalMs
            ? Math.round(CONFIG.update.intervalMs / 60000)
            : null,
        lastCheck: updateState.lastCheck,
        nextCheck: updateState.nextCheck,
        checkCount: updateState.checkCount,
        lastCheckError: updateState.lastCheckError,
        versionUrl: CONFIG.update.versionUrl,
        downloadedPath: updateState.downloadedPath,
        release: detail
            ? {
                releaseType: detail.releaseType || null,
                mandatory: Boolean(detail.mandatory),
                description: detail.description || '',
                downloadLink: detail.downloadLink ? String(detail.downloadLink).trim() : null,
                installShell: detail.installShell || null
            }
            : null
    };
}

// ===========================================================================
//                            ENDPOINT'LER
// ===========================================================================

/**
 * GET /  →  Servis kök bilgisi ve endpoint listesi.
 */
app.get('/', (req, res) => {
    res.json({
        name: 'Gelişmiş Arama API',
        version: localPackage.version || '2.0.0',
        status: 'çalışıyor',
        uptime: formatUptime(Date.now() - START_TIME),
        documentation: 'API_DOCS.md',
        update: {
            localVersion: updateState.localVersion,
            latestVersion: updateState.latestVersion,
            updateAvailable: updateState.updateAvailable,
            endpoint: '/update'
        },
        endpoints: [
            { method: 'GET', path: '/', description: 'Servis bilgisi (bu endpoint)' },
            { method: 'GET', path: '/search', description: 'Arama yapar', query: ['q', 'limit', 'page', 'language', 'categories', 'engines', 'timeRange', 'safeSearch', 'provider', 'noCache'] },
            { method: 'GET', path: '/health', description: 'Sağlık durumu' },
            { method: 'GET', path: '/providers', description: 'Sağlayıcı durumu ve kullanımı' },
            { method: 'GET', path: '/stats', description: 'Kullanım istatistikleri' },
            { method: 'GET', path: '/update', description: 'Güncelleme durumu (?check=true ile anında kontrol)' },
            { method: 'DELETE', path: '/cache', description: 'Önbelleği temizler' }
        ]
    });
});

/**
 * GET /health  →  Uygulama ve sağlayıcı sağlık durumu.
 */
app.get('/health', (req, res) => {
    const readyProviders = Object.entries(providersStatus)
        .filter(([, v]) => v.ready === true)
        .map(([k]) => k);

    res.json({
        status: 'ok',
        uptime: formatUptime(Date.now() - START_TIME),
        uptimeMs: Date.now() - START_TIME,
        timestamp: new Date().toISOString(),
        memory: {
            rss: `${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB`,
            heapUsed: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1)} MB`
        },
        host: os.hostname(),
        readyProviders,
        providers: providersStatus,
        update: buildUpdateReport()
    });
});

/**
 * GET /providers  →  Sağlayıcı listesi ve kullanım sayıları.
 */
app.get('/providers', (req, res) => {
    res.json({
        order: providers.map((p) => p.name),
        providers: providers.map((p) => ({
            name: p.name,
            status: providersStatus[p.name] || { ready: null, note: 'bilinmiyor' },
            usage: stats.providerUsage[p.name] || 0
        }))
    });
});

/**
 * GET /stats  →  Toplam istek, önbellek ve sağlayıcı istatistikleri.
 */
app.get('/stats', (req, res) => {
    const totalCacheLookups = stats.cacheHits + stats.cacheMisses;
    res.json({
        uptime: formatUptime(Date.now() - START_TIME),
        startedAt: stats.startedAt,
        requests: {
            total: stats.totalRequests,
            successful: stats.successfulRequests,
            failed: stats.failedRequests
        },
        cache: {
            entries: cache.size,
            maxEntries: CONFIG.cacheMaxEntries,
            ttlMs: CONFIG.cacheTtlMs,
            hits: stats.cacheHits,
            misses: stats.cacheMisses,
            hitRate: totalCacheLookups ? `${((stats.cacheHits / totalCacheLookups) * 100).toFixed(1)}%` : '0%'
        },
        providerUsage: stats.providerUsage
    });
});

/**
 * GET /update  →  Güncelleme durumu.
 *
 * Query parametreleri:
 *   check  (ops.)  true ise uzak sunucudan ANINDA yeniden kontrol yapar.
 */
app.get('/update', async (req, res, next) => {
    try {
        if (parseBool(req.query.check)) {
            await checkForUpdates('manuel');
        }
        res.json(buildUpdateReport());
    } catch (error) {
        return next(error);
    }
});

/**
 * GET /search  →  Ana arama endpointi.
 *
 * Query parametreleri:
 *   q           (zorunlu)  Arama sorgusu.
 *   limit       (ops.)     Döndürülecek max sonuç. 1-50, varsayılan 10.
 *   page        (ops.)     Sayfa numarası. 1-10, varsayılan 1.
 *   language    (ops.)     Dil kodu (ör. "tr", "en").
 *   categories  (ops.)     Virgülle ayrılmış kategori listesi (ör. "general,news").
 *   engines     (ops.)     Virgülle ayrılmış motor listesi (ör. "google,bing").
 *   timeRange   (ops.)     Zaman aralığı: day, week, month, year.
 *   safeSearch  (ops.)     true/false güvenli arama filtresi.
 *   provider    (ops.)     Belirli bir sağlayıcıyı zorla (searxng|purili|agent-webtool).
 *   noCache     (ops.)     true ise önbelleği atlar.
 */
app.get('/search', rateLimiter, async (req, res, next) => {
    stats.totalRequests++;

    const q = (req.query.q || '').trim();
    if (!q) {
        return res.status(400).json({
            error: "Arama yapmak için 'q' query parametresi zorunludur.",
            example: '/search?q=node.js&limit=5'
        });
    }

    const options = parseSearchOptions(req.query);
    const preferredProvider = req.query.provider || null;
    const noCache = parseBool(req.query.noCache);
    const cacheKey = buildCacheKey(q, options);

    // Önbellek kontrolü
    if (!noCache && !preferredProvider) {
        const cached = cacheGet(cacheKey);
        if (cached) {
            return res.json({ ...cached, cached: true });
        }
    }

    try {
        const result = await performSearch(q, options, preferredProvider);

        const payload = {
            query: q,
            options,
            cached: false,
            ...result
        };

        if (!noCache && result.source) {
            cacheSet(cacheKey, payload);
        }

        return res.json(payload);
    } catch (error) {
        return next(error);
    }
});

/**
 * DELETE /cache  →  Önbelleği temizler.
 */
app.delete('/cache', (req, res) => {
    const cleared = cacheClear();
    res.json({ message: 'Önbellek temizlendi.', clearedEntries: cleared });
});

// ---------------------------------------------------------------------------
// 404 ve hata işleyiciler
// ---------------------------------------------------------------------------
app.use((req, res) => {
    res.status(404).json({
        error: 'Endpoint bulunamadı.',
        path: req.originalUrl,
        hint: "Mevcut endpointler için kök dizini (/) ziyaret edin."
    });
});

app.use((err, req, res, next) => {
    const statusCode = err.statusCode || 500;
    if (statusCode >= 500) console.error('Sunucu hatası:', err);
    res.status(statusCode).json({
        error: err.message || 'Sunucu hatası',
        ...(err.details ? { details: err.details } : {})
    });
});

// ---------------------------------------------------------------------------
// Sunucuyu başlat
// ---------------------------------------------------------------------------
initializeSearch().then(() => {
    const server = app.listen(CONFIG.port, CONFIG.host, () => {
        console.log('==========================================================');
        console.log(`🚀 Arama API'si çalışıyor → http://localhost:${CONFIG.port}`);
        console.log(`   Sürüm: ${updateState.localVersion}`);
        console.log(`   Örnek: http://localhost:${CONFIG.port}/search?q=test&limit=5`);
        console.log(`   Sağlık: http://localhost:${CONFIG.port}/health`);
        console.log(`   Güncelleme: http://localhost:${CONFIG.port}/update`);
        console.log('==========================================================');

        // Güncelleme kontrolünü başlat (açılışta hemen + 30 dakikada bir).
        scheduleUpdateChecks();
    });

    // Graceful shutdown
    const shutdown = (signal) => {
        console.log(`\n${signal} alındı, sunucu kapatılıyor...`);
        server.close(() => {
            console.log('Sunucu kapatıldı.');
            process.exit(0);
        });
        setTimeout(() => process.exit(1), 5000).unref();
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
});
