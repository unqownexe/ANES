/**
 * ============================================================================
 *  Gelişmiş Arama API'si (Advanced Search API)
 * ============================================================================
 *  Çoklu sağlayıcı destekli (SearXNG --> Purili --> agent-webtool) meta-arama
 *  servisi.
 *
 *  YENİ (v2.1):
 *   - Boş sonuç gelirse otomatik 1 retry (jitter'lı) + varyant query desteği
 *   - Boş sonuç → sonraki sağlayıcıya fallback (eskiden başarı sayılıyordu)
 *   - Geçici hatalarda retry (timeout/ECONNRESET vs.)
 *   - Circuit breaker (üst üste N hata → geçici atlama)
 *   - In-flight deduplikasyon (aynı query eş zamanlıysa tek istek)
 *   - LRU cache (FIFO bug'ı düzeltildi) + boş sonuç cache'lenmez
 *   - Rate-limit bucket temizliği (bellek sızıntısı düzeltildi)
 *   - Sonuç deduplikasyonu (aynı URL tekilleştirme)
 *   - /metrics (Prometheus) + X-Request-Id izlenebilirlik
 * ============================================================================
 */

'use strict';

const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');

const execFileAsync = promisify(execFile);

// ---------------------------------------------------------------------------
// Yapılandırma
// ---------------------------------------------------------------------------
const CONFIG = {
    port: parseInt(process.env.PORT, 10) || 8593,
    host: process.env.HOST || '0.0.0.0',
    requestTimeoutMs: parseInt(process.env.REQUEST_TIMEOUT_MS, 10) || 15000,
    defaultLimit: 10,
    maxLimit: 50,
    maxQueryLength: 500,

    cacheTtlMs: parseInt(process.env.CACHE_TTL_MS, 10) || 60000,
    cacheMaxEntries: parseInt(process.env.CACHE_MAX_ENTRIES, 10) || 200,

    // ★ YENİ: Retry davranışı
    retry: {
        onEmpty: process.env.RETRY_ON_EMPTY !== 'false',
        onError: process.env.RETRY_ON_ERROR !== 'false',
        maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS, 10) || 2,
        delayMs: parseInt(process.env.RETRY_DELAY_MS, 10) || 250,
        jitterMs: parseInt(process.env.RETRY_JITTER_MS, 10) || 250,
        useQueryVariants: process.env.RETRY_QUERY_VARIANTS !== 'false'
    },

    // ★ YENİ: Circuit breaker
    circuitBreaker: {
        failureThreshold: parseInt(process.env.CB_FAILURE_THRESHOLD, 10) || 3,
        cooldownMs: parseInt(process.env.CB_COOLDOWN_MS, 10) || 60000
    },

    rateLimit: {
        windowMs: 60000,
        maxRequests: parseInt(process.env.RATE_LIMIT_MAX, 10) || 60,
        cleanupIntervalMs: 5 * 60 * 1000
    },

    update: {
        enabled: process.env.UPDATE_CHECK_ENABLED !== 'false',
        versionUrl:
            process.env.UPDATE_VERSION_URL ||
            'https://raw.githubusercontent.com/unqownexe/ANES/refs/heads/main/Widgets/WebSearcher/updates/version.json',
        intervalMs: parseInt(process.env.UPDATE_CHECK_INTERVAL_MS, 10) || 30 * 60 * 1000,
        timeoutMs: parseInt(process.env.UPDATE_TIMEOUT_MS, 10) || 10000,
        autoDownload: parseBool(process.env.UPDATE_AUTO_DOWNLOAD)
    }
};

/** Anormal env değerlerini güvenli aralığa çek. */
(function validateConfig() {
    CONFIG.retry.maxAttempts = Math.min(Math.max(CONFIG.retry.maxAttempts, 1), 5);
    CONFIG.circuitBreaker.failureThreshold = Math.max(CONFIG.circuitBreaker.failureThreshold, 1);
    CONFIG.circuitBreaker.cooldownMs = Math.max(CONFIG.circuitBreaker.cooldownMs, 1000);
    CONFIG.rateLimit.maxRequests = Math.max(CONFIG.rateLimit.maxRequests, 1);
})();

const START_TIME = Date.now();

// ---------------------------------------------------------------------------
// Uygulama durumu
// ---------------------------------------------------------------------------
const app = express();

let searxngClient = null;

const providersStatus = {
    searxng: { ready: false, note: 'başlatılıyor...' },
    purili: { ready: null, note: 'yüklendiğinde belirlenir' },
    'agent-webtool': { ready: null, note: 'çalıştırıldığında belirlenir' }
};

const stats = {
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    emptyResponses: 0,
    cacheHits: 0,
    cacheMisses: 0,
    totalRetries: 0,
    emptyRetries: 0,
    errorRetries: 0,
    successfulRetries: 0,
    providerUsage: {},
    providerErrors: {},
    startedAt: new Date(START_TIME).toISOString()
};

// ---------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------
function parseList(value) {
    if (!value) return null;
    const list = String(value)
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
    return list.length ? list : null;
}

function parseBool(value) {
    return ['true', '1', 'yes', 'on'].includes(String(value).toLowerCase());
}

function parseIntInRange(value, min, max, fallback) {
    const n = parseInt(value, 10);
    if (Number.isNaN(n)) return fallback;
    return Math.min(Math.max(n, min), max);
}

function formatUptime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const parts = [];
    if (days) parts.push(`${days}g`);
    if (hours) parts.push(`${hours}s`);
    if (minutes) parts.push(`${minutes}dk`);
    parts.push(`${seconds}sn`);
    return parts.join(' ');
}

function withTimeout(promise, ms, label) {
    let timer;
    const timeout = new Promise((_, reject) => {
        timer = setTimeout(
            () => reject(new Error(`'${label}' sağlayıcısı ${ms}ms içinde yanıt vermedi (timeout).`)),
            ms
        );
    });
    return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Query'yi cache key / güvenlik için normalize eder. */
function normalizeQuery(raw) {
    if (!raw) return '';
    return String(raw).replace(/\s+/g, ' ').trim();
}

/**
 * Retry sırasında denenecek alternatif query üretir (boş sonuç gelirse).
 * Çok agresif değil — sadece tırnak/özel karakter temizliği + çok uzun query kısaltma.
 */
function generateQueryVariants(q) {
    const variants = [];
    const noQuotes = q.replace(/["'`„“”]/g, '').replace(/\s+/g, ' ').trim();
    if (noQuotes && noQuotes !== q) variants.push(noQuotes);

    const words = q.split(/\s+/);
    if (words.length > 12) {
        const short = words.slice(0, 12).join(' ');
        if (short !== q && !variants.includes(short)) variants.push(short);
    }
    return variants;
}

/** Geçici (retry'ı hak eden) hata mı? */
function isRetryableError(err) {
    const msg = String((err && err.message) || '').toLowerCase();
    return (
        msg.includes('timeout') ||
        msg.includes('zaman aşımı') ||
        msg.includes('econnreset') ||
        msg.includes('etimedout') ||
        msg.includes('enotfound') ||
        msg.includes('econnrefused') ||
        msg.includes('econnaborted') ||
        msg.includes('socket') ||
        msg.includes('network')
    );
}

/** Sonuç listesindeki aynı URL'leri teke indirir. */
function dedupeResults(results) {
    const seen = new Set();
    const out = [];
    for (const r of results || []) {
        const key = String(r.url || r.title || '').toLowerCase().trim();
        if (!key) continue;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(r);
    }
    return out;
}

// ---------------------------------------------------------------------------
// LRU + TTL önbellek  (FIFO bug'ı düzeltildi)
// ---------------------------------------------------------------------------
const cache = new Map();

function buildCacheKey(query, options) {
    return JSON.stringify({
        q: query,
        limit: options.limit,
        page: options.page,
        language: options.language,
        categories: options.categories,
        engines: options.engines,
        timeRange: options.timeRange,
        safeSearch: options.safeSearch
    });
}

function cacheGet(key) {
    const entry = cache.get(key);
    if (!entry) {
        stats.cacheMisses++;
        return null;
    }
    if (Date.now() > entry.expiresAt) {
        cache.delete(key);
        stats.cacheMisses++;
        return null;
    }
    // LRU: son erişilene taşı
    cache.delete(key);
    cache.set(key, entry);
    stats.cacheHits++;
    return entry.value;
}

function cacheSet(key, value) {
    if (cache.size >= CONFIG.cacheMaxEntries && !cache.has(key)) {
        // En eski (ilk) girdiyi çıkar
        const oldestKey = cache.keys().next().value;
        if (oldestKey !== undefined) cache.delete(oldestKey);
    }
    cache.set(key, { value, expiresAt: Date.now() + CONFIG.cacheTtlMs });
}

function cacheClear() {
    const size = cache.size;
    cache.clear();
    return size;
}

// ---------------------------------------------------------------------------
// In-flight deduplikasyon  (aynı query eş zamanlı → tek istek)
// ---------------------------------------------------------------------------
const inflight = new Map();

function dedupePromise(key, factory) {
    if (inflight.has(key)) return inflight.get(key);
    const promise = factory().finally(() => inflight.delete(key));
    inflight.set(key, promise);
    return promise;
}

// ---------------------------------------------------------------------------
// IP bazlı rate limit + periyodik temizlik
// ---------------------------------------------------------------------------
const rateBuckets = new Map();

function rateLimiter(req, res, next) {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();

    let bucket = rateBuckets.get(ip);
    if (!bucket || now > bucket.resetAt) {
        bucket = { count: 0, resetAt: now + CONFIG.rateLimit.windowMs };
        rateBuckets.set(ip, bucket);
    }
    bucket.count++;

    const remaining = Math.max(0, CONFIG.rateLimit.maxRequests - bucket.count);
    const retryAfter = Math.ceil((bucket.resetAt - now) / 1000);

    res.setHeader('X-RateLimit-Limit', CONFIG.rateLimit.maxRequests);
    res.setHeader('X-RateLimit-Remaining', remaining);
    res.setHeader('X-RateLimit-Reset', retryAfter);

    if (bucket.count > CONFIG.rateLimit.maxRequests) {
        res.setHeader('Retry-After', retryAfter);
        return res.status(429).json({
            error: 'Çok fazla istek gönderildi. Lütfen daha sonra tekrar deneyin.',
            retryAfterSeconds: retryAfter
        });
    }
    next();
}

// Periyodik olarak süresi dolmuş IP kayıtlarını temizle
setInterval(() => {
    const now = Date.now();
    let removed = 0;
    for (const [ip, bucket] of rateBuckets) {
        if (now > bucket.resetAt + CONFIG.rateLimit.windowMs) {
            rateBuckets.delete(ip);
            removed++;
        }
    }
    if (removed > 0) console.log(`[rate] ${removed} eski IP kaydı temizlendi.`);
}, CONFIG.rateLimit.cleanupIntervalMs).unref();

// ---------------------------------------------------------------------------
// Genel middleware'ler
// ---------------------------------------------------------------------------
app.use((req, res, next) => {
    req.id = req.headers['x-request-id'] || crypto.randomBytes(6).toString('hex');
    res.setHeader('X-Request-Id', req.id);

    const start = process.hrtime.bigint();
    const originalWriteHead = res.writeHead;
    res.writeHead = function (...args) {
        const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
        res.setHeader('X-Response-Time', `${durationMs.toFixed(1)}ms`);
        return originalWriteHead.apply(this, args);
    };

    res.on('finish', () => {
        const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
        console.log(
            `[${new Date().toISOString()}] [${req.id}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${durationMs.toFixed(1)}ms)`
        );
    });
    next();
});

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Request-Id');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
});

app.use(express.json({ limit: '100kb' }));

// ---------------------------------------------------------------------------
// Circuit breaker
// ---------------------------------------------------------------------------
const circuitBreaker = { state: {} };

function isCircuitOpen(name) {
    const cb = circuitBreaker.state[name];
    if (!cb || !cb.openUntil) return false;
    return Date.now() <= cb.openUntil;
}

function recordSuccess(name) {
    circuitBreaker.state[name] = { failures: 0, openedAt: null, openUntil: null };
}

function recordFailure(name) {
    const cb = circuitBreaker.state[name] || { failures: 0, openedAt: null, openUntil: null };
    cb.failures++;
    if (cb.failures >= CONFIG.circuitBreaker.failureThreshold) {
        cb.openedAt = Date.now();
        cb.openUntil = Date.now() + CONFIG.circuitBreaker.cooldownMs;
        console.warn(
            `[circuit:${name}] devre AÇILDI (${cb.failures} üst üste hata). ${Math.round(
                CONFIG.circuitBreaker.cooldownMs / 1000
            )}sn boyunca atlanacak.`
        );
    }
    circuitBreaker.state[name] = cb;
}

function circuitSnapshot(name) {
    const cb = circuitBreaker.state[name];
    return {
        open: isCircuitOpen(name),
        failures: cb?.failures || 0,
        openUntil: cb?.openUntil ? new Date(cb.openUntil).toISOString() : null
    };
}

// ---------------------------------------------------------------------------
// Sağlayıcılar
// ---------------------------------------------------------------------------
const providers = [
    {
        name: 'searxng',
        isReady: () => Boolean(searxngClient),
        search: async (query, options) => {
            const params = { q: query };
            if (options.language) params.language = options.language;
            if (options.categories) params.categories = options.categories;
            if (options.engines) params.engines = options.engines;
            if (options.timeRange) params.time_range = options.timeRange;
            if (options.safeSearch !== undefined) params.safesearch = options.safeSearch;
            if (options.page && options.page > 1) params.pageno = options.page;

            const response = await searxngClient.search(params);
            const results = (response.results || []).map((r) => ({
                title: r.title,
                url: r.url,
                snippet: r.content,
                engine: r.engine,
                category: r.category,
                score: r.score
            }));
            return {
                results,
                meta: {
                    numberOfResults: response.number_of_results,
                    query: response.query,
                    engines: response.engines
                }
            };
        }
    },
    {
        name: 'purili',
        isReady: () => providersStatus.purili.ready,
        search: async (query) => {
            const { purili } = await import('@purili/web-search');
            const response = await purili.search(query);
            const results = (response.results || []).map((r) => ({
                title: r.title,
                url: r.url,
                snippet: r.snippet
            }));
            return { results, meta: {} };
        }
    },
    {
        name: 'agent-webtool',
        search: async (query, options) => {
            const { stdout } = await execFileAsync('webtool', [
                'search',
                query,
                '--limit',
                String(options.limit)
            ]);
            return {
                results: [
                    {
                        title: `agent-webtool sonuçları: ${query}`,
                        url: null,
                        snippet: stdout.trim(),
                        raw: true
                    }
                ],
                meta: { format: 'markdown' }
            };
        }
    }
];

function getProvider(name) {
    return providers.find((p) => p.name === name) || null;
}

function trackProviderUsage(name) {
    stats.providerUsage[name] = (stats.providerUsage[name] || 0) + 1;
}

function trackProviderError(name) {
    stats.providerErrors[name] = (stats.providerErrors[name] || 0) + 1;
}

/**
 * ★ YENİ: Tek bir sağlayıcı üzerinde retry mantığı.
 *
 * Kurallar:
 *   - Sonuç dönerse: başarı.
 *   - Boş dönerse: maxAttempts'e kadar tekrar dene (delay + jitter,
 *     ve varsa varyant query).
 *   - Hata olursa: isRetryableError ve onError ise tekrar dene, değilse çık.
 *
 * Dönüş: { status: 'ok'|'empty'|'error', results, meta, attempts, tookMs, usedQuery }
 */
async function searchWithRetry(provider, query, options) {
    const maxAttempts = CONFIG.retry.maxAttempts;
    const attempts = [];
    const variants = CONFIG.retry.useQueryVariants ? generateQueryVariants(query) : [];
    let variantIndex = 0;
    let currentQuery = query;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        const startedAt = Date.now();
        try {
            const { results, meta } = await withTimeout(
                provider.search(currentQuery, options),
                CONFIG.requestTimeoutMs,
                provider.name
            );
            const tookMs = Date.now() - startedAt;
            const count = (results || []).length;

            if (count > 0) {
                attempts.push({ attempt, query: currentQuery, status: 'ok', tookMs, count });
                if (attempt > 1) stats.successfulRetries++;
                return { status: 'ok', results, meta, attempts, tookMs, usedQuery: currentQuery };
            }

            // Boş sonuç
            attempts.push({ attempt, query: currentQuery, status: 'empty', tookMs, count: 0 });
            stats.emptyResponses++;

            if (CONFIG.retry.onEmpty && attempt < maxAttempts) {
                stats.totalRetries++;
                stats.emptyRetries++;

                // Varyant query varsa sıradakini kullan
                if (variantIndex < variants.length) {
                    currentQuery = variants[variantIndex++];
                }
                const delay =
                    CONFIG.retry.delayMs + Math.floor(Math.random() * CONFIG.retry.jitterMs);
                console.log(
                    `[retry:${provider.name}] boş sonuç (${attempt}/${maxAttempts}) → ` +
                    `${delay}ms sonra tekrar deniyor${currentQuery !== query ? ' (varyant query)' : ''}.`
                );
                await sleep(delay);
            } else {
                // retry kapalı veya son deneme → boş olarak dön
                return { status: 'empty', results: [], meta: {}, attempts, usedQuery: currentQuery };
            }
        } catch (error) {
            const tookMs = Date.now() - startedAt;
            attempts.push({ attempt, query: currentQuery, status: 'error', tookMs, error: error.message });

            const canRetry = CONFIG.retry.onError && isRetryableError(error) && attempt < maxAttempts;
            if (canRetry) {
                stats.totalRetries++;
                stats.errorRetries++;
                const delay =
                    CONFIG.retry.delayMs + Math.floor(Math.random() * CONFIG.retry.jitterMs);
                console.log(
                    `[retry:${provider.name}] hata '${error.message}' (${attempt}/${maxAttempts}) → ` +
                    `${delay}ms sonra tekrar deniyor.`
                );
                await sleep(delay);
                continue;
            }
            return { status: 'error', error, attempts, usedQuery: currentQuery };
        }
    }

    return { status: 'empty', results: [], meta: {}, attempts, usedQuery: currentQuery };
}

/**
 * Zincirdeki tüm sağlayıcıları dener.
 * Retry-on-empty searchWithRetry içinde hallediliyor.
 */
async function performSearch(query, options, preferredProvider) {
    const chain = preferredProvider
        ? providers.filter((p) => p.name === preferredProvider)
        : providers;

    if (preferredProvider && chain.length === 0) {
        const err = new Error(`Bilinmeyen sağlayıcı: '${preferredProvider}'`);
        err.statusCode = 400;
        throw err;
    }

    const errors = [];
    const providerReports = [];
    let firstEmptyProvider = null;
    const overallStart = Date.now();

    for (const provider of chain) {
        if (isCircuitOpen(provider.name)) {
            providerReports.push({
                provider: provider.name,
                status: 'skipped',
                reason: 'circuit-breaker açık'
            });
            continue;
        }

        if (typeof provider.isReady === 'function' && !provider.isReady()) {
            providerReports.push({ provider: provider.name, status: 'skipped', reason: 'hazır değil' });
            errors.push({ provider: provider.name, error: 'Sağlayıcı hazır değil (atlandı)' });
            continue;
        }

        const result = await searchWithRetry(provider, query, options);

        if (result.status === 'ok') {
            recordSuccess(provider.name);
            trackProviderUsage(provider.name);

            const deduped = dedupeResults(result.results);
            const limited = deduped.slice(0, options.limit);
            stats.successfulRequests++;

            return {
                source: provider.name,
                fallbackChain: [provider.name],
                tookMs: Date.now() - overallStart,
                count: limited.length,
                results: limited,
                meta: result.meta || {},
                attempts: result.attempts,
                usedQuery: result.usedQuery,
                empty: limited.length === 0,
                ...(errors.length ? { warnings: errors } : {})
            };
        }

        if (result.status === 'empty') {
            // ★ Önemli: boş sonuç başarı DEĞİL — sıradaki sağlayıcıyı dene.
            if (!firstEmptyProvider) firstEmptyProvider = provider.name;
            providerReports.push({
                provider: provider.name,
                status: 'empty',
                attempts: result.attempts
            });
            continue;
        }

        // status === 'error'
        recordFailure(provider.name);
        trackProviderError(provider.name);
        errors.push({ provider: provider.name, error: result.error.message });
        providerReports.push({
            provider: provider.name,
            status: 'error',
            error: result.error.message,
            attempts: result.attempts
        });
        console.warn(`[provider:${provider.name}] tüm denemeler başarısız: ${result.error.message}`);
    }

    // Tüm sağlayıcılar tükendi
    if (firstEmptyProvider) {
        // En az bir sağlayıcı çalıştı ama boş döndü → 200 + empty flag
        stats.successfulRequests++;
        return {
            source: firstEmptyProvider,
            fallbackChain: providerReports.filter((p) => p.status !== 'skipped').map((p) => p.provider),
            tookMs: Date.now() - overallStart,
            count: 0,
            results: [],
            meta: {},
            empty: true,
            attempts: providerReports,
            warnings: errors.length ? errors : undefined,
            note: 'Hiçbir sağlayıcı sonuç bulamadı (boş sonuç).'
        };
    }

    stats.failedRequests++;
    const finalError = new Error('Tüm arama sağlayıcıları başarısız oldu.');
    finalError.statusCode = 502;
    finalError.details = { errors, providers: providerReports };
    throw finalError;
}

// ---------------------------------------------------------------------------
// Başlangıç
// ---------------------------------------------------------------------------
async function initializeSearch() {
    try {
        const { startServer } = require('@searxng-js/searxng');
        const server = await startServer();
        searxngClient = server.client;
        providersStatus.searxng = { ready: true, note: 'hazır' };
        console.log('✅ SearXNG sunucusu hazır.');
    } catch (error) {
        providersStatus.searxng = { ready: false, note: error.message };
        console.error('❌ SearXNG başlatılamadı, yedek sağlayıcılar kullanılacak:', error.message);
    }

    try {
        await import('@purili/web-search');
        providersStatus.purili = { ready: true, note: 'modül yüklü (ESM)' };
    } catch (error) {
        providersStatus.purili = { ready: false, note: error.message };
    }

    try {
        await execFileAsync('webtool', ['--version']);
        providersStatus['agent-webtool'] = { ready: true, note: 'CLI erişilebilir' };
    } catch {
        providersStatus['agent-webtool'] = {
            ready: false,
            note: "CLI bulunamadı ('npm install -g agent-webtool')"
        };
    }
}

function parseSearchOptions(query) {
    return {
        limit: parseIntInRange(query.limit, 1, CONFIG.maxLimit, CONFIG.defaultLimit),
        page: parseIntInRange(query.page, 1, 10, 1),
        language: query.language || null,
        categories: parseList(query.categories),
        engines: parseList(query.engines),
        timeRange: query.timeRange || null,
        safeSearch: query.safeSearch !== undefined ? parseBool(query.safeSearch) : undefined
    };
}

// ---------------------------------------------------------------------------
// Güncelleme kontrolü (aynı kaldı)
// ---------------------------------------------------------------------------
function readLocalPackage() {
    try {
        return JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
    } catch (error) {
        console.warn(`[update] package.json okunamadı: ${error.message}`);
        return { version: '0.0.0' };
    }
}

function parseVersion(version) {
    const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(version || '').trim());
    if (!m) return null;
    return { major: parseInt(m[1], 10), minor: parseInt(m[2], 10), patch: parseInt(m[3], 10) };
}

function compareVersions(a, b) {
    const pa = parseVersion(a);
    const pb = parseVersion(b);
    if (!pa || !pb) return 0;
    if (pa.major !== pb.major) return pa.major - pb.major;
    if (pa.minor !== pb.minor) return pa.minor - pb.minor;
    return pa.patch - pb.patch;
}

function latestFromDetails(details) {
    if (!details || typeof details !== 'object') return null;
    const versions = Object.keys(details);
    if (!versions.length) return null;
    versions.sort((a, b) => compareVersions(b, a));
    return versions[0];
}

const localPackage = readLocalPackage();

const updateState = {
    enabled: CONFIG.update.enabled,
    localVersion: localPackage.version || '0.0.0',
    latestVersion: null,
    updateAvailable: false,
    mandatory: false,
    lastCheck: null,
    lastCheckError: null,
    nextCheck: null,
    checkCount: 0,
    downloadedPath: null,
    lastRemote: null
};

let updateTimer = null;

function httpGetJson(url, timeoutMs) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(
            url,
            { timeout: timeoutMs, headers: { 'User-Agent': 'ANES-WebSearcher-UpdateChecker' } },
            (res) => {
                if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                    res.resume();
                    const nextUrl = new URL(res.headers.location, url).toString();
                    return resolve(httpGetJson(nextUrl, timeoutMs));
                }
                if (res.statusCode !== 200) {
                    res.resume();
                    return reject(new Error(`Beklenmeyen HTTP durumu: ${res.statusCode}`));
                }
                let data = '';
                res.setEncoding('utf8');
                res.on('data', (chunk) => { data += chunk; });
                res.on('end', () => {
                    try { resolve(JSON.parse(data)); }
                    catch (error) { reject(new Error(`Geçersiz JSON yanıtı: ${error.message}`)); }
                });
            }
        );
        req.on('timeout', () => req.destroy(new Error(`İstek zaman aşımına uğradı (${timeoutMs}ms).`)));
        req.on('error', reject);
    });
}

function httpDownload(url, destPath, timeoutMs) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(
            url,
            { timeout: timeoutMs, headers: { 'User-Agent': 'ANES-WebSearcher-UpdateChecker' } },
            (res) => {
                if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                    res.resume();
                    const nextUrl = new URL(res.headers.location, url).toString();
                    return resolve(httpDownload(nextUrl, destPath, timeoutMs));
                }
                if (res.statusCode !== 200) {
                    res.resume();
                    return reject(new Error(`Beklenmeyen HTTP durumu: ${res.statusCode}`));
                }
                fs.mkdirSync(path.dirname(destPath), { recursive: true });
                const fileStream = fs.createWriteStream(destPath);
                res.pipe(fileStream);
                fileStream.on('finish', () => fileStream.close(() => resolve(destPath)));
                fileStream.on('error', reject);
            }
        );
        req.on('timeout', () => req.destroy(new Error(`İndirme zaman aşımına uğradı (${timeoutMs}ms).`)));
        req.on('error', reject);
    });
}

async function downloadUpdate(link, version) {
    const clean = String(link).trim();
    let fileName = `ANES-WebSearch-${version}.zip`;
    try {
        const base = path.basename(new URL(clean).pathname);
        if (base) fileName = base;
    } catch { /* varsayılan */ }

    const destPath = path.join(__dirname, 'update-cache', fileName);
    console.log(`⬇️  Güncelleme indiriliyor: ${fileName}`);
    await httpDownload(clean, destPath, Math.max(CONFIG.update.timeoutMs, 60000));
    updateState.downloadedPath = destPath;
    console.log(`✅ Güncelleme indirildi: ${destPath}`);
    return destPath;
}

async function checkForUpdates(reason = 'manuel') {
    if (!CONFIG.update.enabled) return updateState;

    updateState.checkCount++;
    try {
        const remote = await httpGetJson(CONFIG.update.versionUrl, CONFIG.update.timeoutMs);
        const latest = remote.lastVersion || latestFromDetails(remote.VersionDetails);
        const detail =
            remote.VersionDetails && latest ? remote.VersionDetails[latest] : null;

        updateState.lastRemote = remote;
        updateState.latestVersion = latest || null;
        updateState.lastCheck = new Date().toISOString();
        updateState.lastCheckError = null;

        const available = Boolean(latest) && compareVersions(latest, updateState.localVersion) > 0;
        const wasAvailable = updateState.updateAvailable;
        updateState.updateAvailable = available;
        updateState.mandatory = Boolean(detail && detail.mandatory);

        if (available) {
            console.log(
                `⬆️  Yeni sürüm mevcut: ${updateState.localVersion} → ${latest}` +
                (updateState.mandatory ? ' (ZORUNLU)' : '')
            );
            if (detail && detail.downloadLink && (CONFIG.update.autoDownload || reason === 'manuel')) {
                if (!updateState.downloadedPath || reason === 'manuel') {
                    downloadUpdate(detail.downloadLink, latest).catch((error) =>
                        console.warn(`[update] Arşiv indirilemedi: ${error.message}`)
                    );
                }
            }
        } else if (!wasAvailable) {
            console.log(`[update] Güncel (yerel: ${updateState.localVersion}, uzak: ${latest || 'bilinmiyor'}) [${reason}]`);
        }
        return updateState;
    } catch (error) {
        updateState.lastCheck = new Date().toISOString();
        updateState.lastCheckError = error.message;
        console.warn(`[update] Kontrol başarısız (${reason}): ${error.message}`);
        return updateState;
    } finally {
        updateState.nextCheck = new Date(Date.now() + CONFIG.update.intervalMs).toISOString();
    }
}

function scheduleUpdateChecks() {
    if (!CONFIG.update.enabled) {
        console.log('ℹ️  Güncelleme kontrolü devre dışı (UPDATE_CHECK_ENABLED=false).');
        return;
    }
    checkForUpdates('başlangıç');
    updateTimer = setInterval(() => checkForUpdates('periyodik'), CONFIG.update.intervalMs);
    if (typeof updateTimer.unref === 'function') updateTimer.unref();
    updateState.nextCheck = new Date(Date.now() + CONFIG.update.intervalMs).toISOString();
    const minutes = Math.round(CONFIG.update.intervalMs / 60000);
    console.log(`🔄 Güncelleme kontrolü aktif → açılışta ve her ${minutes} dakikada bir.`);
}

function buildUpdateReport() {
    const remote = updateState.lastRemote;
    const detail =
        remote && remote.VersionDetails && updateState.latestVersion
            ? remote.VersionDetails[updateState.latestVersion]
            : null;

    return {
        enabled: updateState.enabled,
        localVersion: updateState.localVersion,
        latestVersion: updateState.latestVersion,
        updateAvailable: updateState.updateAvailable,
        checkIntervalMinutes: CONFIG.update.intervalMs
            ? Math.round(CONFIG.update.intervalMs / 60000)
            : null,
        lastCheck: updateState.lastCheck,
        nextCheck: updateState.nextCheck,
        checkCount: updateState.checkCount,
        lastCheckError: updateState.lastCheckError,
        versionUrl: CONFIG.update.versionUrl,
        downloadedPath: updateState.downloadedPath,
        release: detail
            ? {
                releaseType: detail.releaseType || null,
                mandatory: Boolean(detail.mandatory),
                description: detail.description || '',
                downloadLink: detail.downloadLink ? String(detail.downloadLink).trim() : null,
                installShell: detail.installShell || null
            }
            : null
    };
}

// ===========================================================================
//                            ENDPOINT'LER
// ===========================================================================

app.get('/', (req, res) => {
    res.json({
        name: 'Gelişmiş Arama API',
        version: localPackage.version || '2.1.0',
        status: 'çalışıyor',
        uptime: formatUptime(Date.now() - START_TIME),
        documentation: 'API_DOCS.md',
        config: {
            retry: {
                onEmpty: CONFIG.retry.onEmpty,
                onError: CONFIG.retry.onError,
                maxAttempts: CONFIG.retry.maxAttempts,
                useQueryVariants: CONFIG.retry.useQueryVariants
            },
            circuitBreaker: CONFIG.circuitBreaker
        },
        update: {
            localVersion: updateState.localVersion,
            latestVersion: updateState.latestVersion,
            updateAvailable: updateState.updateAvailable,
            endpoint: '/update'
        },
        endpoints: [
            { method: 'GET', path: '/', description: 'Servis bilgisi' },
            { method: 'GET', path: '/search', description: 'Arama yapar', query: ['q', 'limit', 'page', 'language', 'categories', 'engines', 'timeRange', 'safeSearch', 'provider', 'noCache'] },
            { method: 'GET', path: '/health', description: 'Sağlık durumu' },
            { method: 'GET', path: '/providers', description: 'Sağlayıcı durumu ve kullanımı' },
            { method: 'GET', path: '/stats', description: 'Kullanım istatistikleri' },
            { method: 'GET', path: '/metrics', description: 'Prometheus metrikleri' },
            { method: 'GET', path: '/update', description: 'Güncelleme durumu (?check=true ile anında kontrol)' },
            { method: 'DELETE', path: '/cache', description: 'Önbelleği temizler' }
        ]
    });
});

app.get('/health', (req, res) => {
    const readyProviders = Object.entries(providersStatus)
        .filter(([, v]) => v.ready === true)
        .map(([k]) => k);

    res.json({
        status: 'ok',
        uptime: formatUptime(Date.now() - START_TIME),
        uptimeMs: Date.now() - START_TIME,
        timestamp: new Date().toISOString(),
        memory: {
            rss: `${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB`,
            heapUsed: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1)} MB`
        },
        host: os.hostname(),
        readyProviders,
        providers: providersStatus,
        circuitBreakers: Object.fromEntries(
            providers.map((p) => [p.name, circuitSnapshot(p.name)])
        ),
        inflightRequests: inflight.size,
        update: buildUpdateReport()
    });
});

app.get('/providers', (req, res) => {
    res.json({
        order: providers.map((p) => p.name),
        providers: providers.map((p) => ({
            name: p.name,
            status: providersStatus[p.name] || { ready: null, note: 'bilinmiyor' },
            usage: stats.providerUsage[p.name] || 0,
            errors: stats.providerErrors[p.name] || 0,
            circuit: circuitSnapshot(p.name)
        }))
    });
});

app.get('/stats', (req, res) => {
    const totalCacheLookups = stats.cacheHits + stats.cacheMisses;
    res.json({
        uptime: formatUptime(Date.now() - START_TIME),
        startedAt: stats.startedAt,
        requests: {
            total: stats.totalRequests,
            successful: stats.successfulRequests,
            failed: stats.failedRequests,
            empty: stats.emptyResponses
        },
        retries: {
            total: stats.totalRetries,
            onEmpty: stats.emptyRetries,
            onError: stats.errorRetries,
            successful: stats.successfulRetries
        },
        cache: {
            entries: cache.size,
            maxEntries: CONFIG.cacheMaxEntries,
            ttlMs: CONFIG.cacheTtlMs,
            hits: stats.cacheHits,
            misses: stats.cacheMisses,
            hitRate: totalCacheLookups ? `${((stats.cacheHits / totalCacheLookups) * 100).toFixed(1)}%` : '0%'
        },
        providerUsage: stats.providerUsage,
        providerErrors: stats.providerErrors,
        circuitBreakers: Object.fromEntries(
            providers.map((p) => [p.name, circuitSnapshot(p.name)])
        ),
        inflightRequests: inflight.size
    });
});

// ★ YENİ: Prometheus metrikleri
app.get('/metrics', (req, res) => {
    const lines = [];
    const m = (name, help, type, value) => {
        lines.push(`# HELP ${name} ${help}`);
        lines.push(`# TYPE ${name} ${type}`);
        lines.push(`${name} ${value}`);
    };

    m('websearch_requests_total', 'Toplam istek', 'counter', stats.totalRequests);
    m('websearch_requests_successful_total', 'Başarılı istek', 'counter', stats.successfulRequests);
    m('websearch_requests_failed_total', 'Başarısız istek', 'counter', stats.failedRequests);
    m('websearch_requests_empty_total', 'Boş sonuçlu istek', 'counter', stats.emptyResponses);
    m('websearch_cache_hits_total', 'Cache hit', 'counter', stats.cacheHits);
    m('websearch_cache_misses_total', 'Cache miss', 'counter', stats.cacheMisses);
    m('websearch_retries_total', 'Toplam retry', 'counter', stats.totalRetries);
    m('websearch_retries_empty_total', 'Boş sonuç retry', 'counter', stats.emptyRetries);
    m('websearch_retries_error_total', 'Hata retry', 'counter', stats.errorRetries);
    m('websearch_retries_successful_total', 'Başarılı retry', 'counter', stats.successfulRetries);
    m('websearch_uptime_seconds', 'Uptime (sn)', 'gauge', Math.floor((Date.now() - START_TIME) / 1000));

    lines.push('# HELP websearch_provider_usage_total Sağlayıcı kullanımı');
    lines.push('# TYPE websearch_provider_usage_total counter');
    for (const [name, count] of Object.entries(stats.providerUsage)) {
        lines.push(`websearch_provider_usage_total{provider="${name}"} ${count}`);
    }

    lines.push('# HELP websearch_provider_errors_total Sağlayıcı hataları');
    lines.push('# TYPE websearch_provider_errors_total counter');
    for (const [name, count] of Object.entries(stats.providerErrors)) {
        lines.push(`websearch_provider_errors_total{provider="${name}"} ${count}`);
    }

    lines.push('# HELP websearch_circuit_open Devre durumu (1=açık)');
    lines.push('# TYPE websearch_circuit_open gauge');
    for (const p of providers) {
        lines.push(`websearch_circuit_open{provider="${p.name}"} ${isCircuitOpen(p.name) ? 1 : 0}`);
    }

    res.setHeader('Content-Type', 'text/plain; version=0.0.4; charset=utf-8');
    res.send(lines.join('\n') + '\n');
});

app.get('/update', async (req, res, next) => {
    try {
        if (parseBool(req.query.check)) await checkForUpdates('manuel');
        res.json(buildUpdateReport());
    } catch (error) { return next(error); }
});

// ★ YENİ davranış: boş sonuç -> sonraki sağlayıcı, retry, in-flight dedupe.
app.get('/search', rateLimiter, async (req, res, next) => {
    stats.totalRequests++;

    const q = normalizeQuery(req.query.q);
    if (!q) {
        return res.status(400).json({
            error: "Arama yapmak için 'q' query parametresi zorunludur.",
            example: '/search?q=node.js&limit=5'
        });
    }
    if (q.length > CONFIG.maxQueryLength) {
        return res.status(400).json({
            error: `Query çok uzun. Maksimum ${CONFIG.maxQueryLength} karakter.`,
            length: q.length
        });
    }

    const options = parseSearchOptions(req.query);
    const preferredProvider = req.query.provider || null;
    const noCache = parseBool(req.query.noCache);
    const cacheKey = buildCacheKey(q, options);
    const dedupeKey = `${cacheKey}|${preferredProvider || ''}`;

    // Cache kontrolü
    if (!noCache && !preferredProvider) {
        const cached = cacheGet(cacheKey);
        if (cached) {
            res.setHeader('X-Cache', 'HIT');
            res.setHeader('X-Search-Source', cached.source || 'none');
            res.setHeader('X-Search-Count', cached.count || 0);
            return res.json({ ...cached, cached: true });
        }
        res.setHeader('X-Cache', 'MISS');
    }

    try {
        const result = await dedupePromise(dedupeKey, () =>
            performSearch(q, options, preferredProvider)
        );

        const payload = { query: q, options, cached: false, ...result };

        // Boş sonuçları CACHE'LEME (transient boşluk 60sn kilitlenmesin)
        if (!noCache && result.source && result.count > 0) {
            cacheSet(cacheKey, payload);
        }

        res.setHeader('X-Search-Source', result.source || 'none');
        res.setHeader('X-Search-Count', result.count || 0);
        res.setHeader('X-Search-Empty', result.empty ? 'true' : 'false');

        return res.json(payload);
    } catch (error) {
        return next(error);
    }
});

app.delete('/cache', (req, res) => {
    const cleared = cacheClear();
    res.json({ message: 'Önbellek temizlendi.', clearedEntries: cleared });
});

// ---------------------------------------------------------------------------
// 404 & hata işleyiciler
// ---------------------------------------------------------------------------
app.use((req, res) => {
    res.status(404).json({
        error: 'Endpoint bulunamadı.',
        path: req.originalUrl,
        hint: 'Mevcut endpointler için kök dizini (/) ziyaret edin.'
    });
});

app.use((err, req, res, next) => {
    const statusCode = err.statusCode || 500;
    if (statusCode >= 500) console.error(`[${req.id}] Sunucu hatası:`, err);
    res.status(statusCode).json({
        error: err.message || 'Sunucu hatası',
        requestId: req.id,
        ...(err.details ? { details: err.details } : {})
    });
});

// ---------------------------------------------------------------------------
// Sunucuyu başlat
// ---------------------------------------------------------------------------
initializeSearch().then(() => {
    const server = app.listen(CONFIG.port, CONFIG.host, () => {
        console.log('==========================================================');
        console.log(`🚀 Arama API'si çalışıyor → http://localhost:${CONFIG.port}`);
        console.log(`   Sürüm: ${updateState.localVersion}`);
        console.log(`   Retry: onEmpty=${CONFIG.retry.onEmpty}, onError=${CONFIG.retry.onError}, maxAttempts=${CONFIG.retry.maxAttempts}`);
        console.log(`   Circuit breaker: ${CONFIG.circuitBreaker.failureThreshold} hata → ${CONFIG.circuitBreaker.cooldownMs / 1000}sn atlama`);
        console.log(`   Örnek: http://localhost:${CONFIG.port}/search?q=test&limit=5`);
        console.log(`   Sağlık: http://localhost:${CONFIG.port}/health`);
        console.log(`   Metrik: http://localhost:${CONFIG.port}/metrics`);
        console.log('==========================================================');
        scheduleUpdateChecks();
    });

    const shutdown = (signal) => {
        console.log(`\n${signal} alındı, sunucu kapatılıyor...`);
        server.close(() => {
            console.log('Sunucu kapatıldı.');
            process.exit(0);
        });
        setTimeout(() => process.exit(1), 5000).unref();
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
});